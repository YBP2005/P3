# -*- coding: utf-8 -*-
"""英文稿统一校验器（合并 en_finalize3 的验收 + en_number_audit 的溯源 + 两条新增结构性断言）。

新增断言（教训 06_改动纪律与产物保全：结构性编辑必须有结构性断言）：
  N1 附录交叉引用可解析：正文每个 (Appendix X.Y) / Appendix X.Y 必须命中补充材料中的实际标题。
  N2 搬出内容仍在附录：从主文 §3.6 移走的五分类判据/去重协议必须在附录 B.1–B.2 找到。
只读，不改任何产物。退出码 0=全过，1=有失败项。
"""
import io, os, re, sys, hashlib, json
sys.stdout.reconfigure(encoding='utf-8')

ROOT = r'D:\deepseek\PaperB'
PKG = os.path.join(ROOT, 'review_pkg_20260919')
EN = os.path.join(ROOT, 'PaperB_英文稿_PR_20260919.md')
SUP = os.path.join(ROOT, 'PaperB_英文补充材料_PR_20260919.md')
ZH = os.path.join(ROOT, 'PaperB_章节骨架_v3_可确证性_20260911.md')
# 第二数字权威：命题 4–6 的验证记录。其数字是**当场计算**得出（README 第 4 条
# 「数字能算就不要抄」），不是从中文定稿翻译来的，故单列为第二权威。
IDENTITY_AUTHORITY = os.path.join(ROOT, 'PaperB_命题4-6验证记录_20260919.md')
# 第三权威：参考文献取回记录。条目里的年份/编号等数字**来自 P40 上的 arXiv/Crossref 取回**，
# 不是从中文定稿翻译来的，故单列（同 IDENTITY_AUTHORITY 的道理）。
ARXIV_AUTHORITY = os.path.join(ROOT, 'analysis', 'work', '_arxiv_records.json')
ARXIV_AUTHORITY2 = os.path.join(ROOT, 'analysis', 'work', '_refs_inventory.json')
ARXIV_AUTHORITY3 = os.path.join(ROOT, 'analysis', 'work', '_refs_extra.json')
# 第四权威：E1 判别实验的证据记录（2026-09-20）。E1 的数字由 5090 上的实测产出
# （48 格、1591/1591、2.463–9.452、语料 2496 行），既非中文定稿的翻译、也非参考文献取回，
# 与 IDENTITY_AUTHORITY 同理单列。
E1_AUTHORITY = os.path.join(ROOT, 'PaperB_E1证据_20260920.md')

en = io.open(EN, encoding='utf-8', newline='').read()
sup = io.open(SUP, encoding='utf-8', newline='').read()
zh = io.open(ZH, encoding='utf-8', newline='').read()
au = io.open(IDENTITY_AUTHORITY, encoding='utf-8', newline='').read() if os.path.exists(IDENTITY_AUTHORITY) else ''
ar = (io.open(ARXIV_AUTHORITY, encoding='utf-8', newline='').read() if os.path.exists(ARXIV_AUTHORITY) else '')
ar += (io.open(ARXIV_AUTHORITY2, encoding='utf-8', newline='').read() if os.path.exists(ARXIV_AUTHORITY2) else '')
ar += (io.open(ARXIV_AUTHORITY3, encoding='utf-8', newline='').read() if os.path.exists(ARXIV_AUTHORITY3) else '')
# 第三组：2026-09-20 补引用的取回记录（Crossref/OpenAlex，经 P40）——
# 新引用的年份、DOI、卷期等数字取自这些记录，故同列为权威。
for _rf in ('_pb_refs_out.json', '_pb_refs2_out.json', '_pb_refs34_out.json'):
    _rp = os.path.join(ROOT, 'analysis', 'work', _rf)
    if os.path.exists(_rp):
        ar += io.open(_rp, encoding='utf-8', newline='').read()
e1n = (io.open(E1_AUTHORITY, encoding='utf-8', newline='').read() if os.path.exists(E1_AUTHORITY) else '')
W = lambda s: len(re.findall(r"[A-Za-z][A-Za-z'\-]*", s))

fails = []
def chk(name, ok, detail=''):
    print('  [%s] %-46s %s' % ('OK  ' if ok else 'FAIL', name, detail))
    if not ok:
        fails.append(name)

print('=' * 100)
print('英文稿统一校验')
print('=' * 100)

# ---------- A. 结构 ----------
print('\n[A] 结构完整性')
SEC = ['## Abstract', '## 1. Introduction', '## 2. Related Work', '## 3. Method', '## 4. Results I',
       '## 5. Results II', '## 6. Results III', '## 7. Discussion', '## 8. Limitations', '## References']
miss = [s for s in SEC if s not in en]
chk('章节 %d/%d' % (len(SEC) - len(miss), len(SEC)), not miss, str(miss or ''))

order = [int(m.group(1)) for m in re.finditer(r'^### 3\.(\d+) ', en, re.M)]
chk('§3 子节编号 1–9 连续', order == sorted(order) == list(range(1, 10)), str(order))

for chap, pat in [('2', r'^### 2\.(\d+) '), ('4', r'^### 4\.(\d+) '), ('5', r'^### 5\.(\d+) '),
                  ('7', r'^### 7\.(\d+) '), ('8', r'^### 8\.(\d+) ')]:
    o = [int(m.group(1)) for m in re.finditer(pat, en, re.M)]
    chk('§%s 子节编号连续（%d 节）' % (chap, len(o)), o == sorted(o) and o == list(range(1, len(o) + 1)), str(o))

# 10 个正文章节 + 1 个 Appendix C 指针段 = 11 个 ## 标题
h2 = re.findall(r'^## (.+)$', en, re.M)
chk('顶层标题 15 个（10 章 + 附录指针 + PR 要求的 4 节声明/结论）',
    len(h2) == 15, '实际 %d' % len(h2))
chk('末位列 References 之后仅剩 Appendix C 指针',
    h2[-1].startswith('Appendix C') and h2[-2] == 'References', str(h2[-2:]))

# ---------- B. 声称-限定对齐（§15.1 三方表） ----------
print('\n[B] 声称-限定对齐与形式要件')
DISC = ['Run-to-run non-determinism', 'Graded isolation', 'census of anomalous predictions',
        'Two runner defects', 'No attention-based criterion', 'Per-cell intervals are lower bounds',
        'optimal input fidelity was not located', 'attribution boundary is behavioural',
        'detector lineage is narrow', 'corpus is dominated by one lineage',
        'Domain composition is not systematic', 'not pre-registered as a whole',
        'power for the spectrum is low']
m2 = [d for d in DISC if d not in en]
chk('披露条目 %d/%d' % (len(DISC) - len(m2), len(DISC)), not m2, str(m2 or ''))

nprop = sum('Proposition %d' % k in en for k in (1, 2, 3, 4, 5, 6))
chk('命题 6/6（1–2 识别与口径，3–6 跨度/分解/标定/分层）', nprop == 6, '%d' % nprop)

# T1/A1/C1 降级后的措辞必须仍在（防止回退成泛化声称）
chk('A1 已降级为 open-weight + 血统限定', 'open-weight' in en and 'two lineages' in en)
chk('A2 已标注 GT 加权口径', 'ground-truth-weighted' in en)
chk('A7 实现效应 2–3.4×', '2–3.4' in en or '2-3.4' in en)
chk('P4 已声明与 §5.11(a) 的四格差值一致（措辞已改为一致性核对）',
    'Proposition 4 expresses this gap as' in en and 'consistency check on the numbers printed' in en)
chk('P5 已声明等变性（需 s≪1）', 's\\ll1' in en.replace('$\\ll$', '\\ll'))
chk('P6 已给出非序等价判据', 'legibility-consistent' in en)
chk('§8.1 已含实测离散上界 0.81 pp', '0.81 pp' in en)
chk('A8 同义反复已立为 Proposition 3',
    r'exactly $\pm 1$' in en and 'component of the' in en and 'magnitude is not predicted' in en)

# ---------- C. N1 附录交叉引用可解析 ----------
print('\n[C] 附录交叉引用可解析性（新增断言 N1）')
supheads = set()
for m in re.finditer(r'^#{2,4}\s+(?:Appendix\s+)?([A-M](?:\.\d+)?)[\.\s]', sup, re.M):
    supheads.add(m.group(1))
refs = set(re.findall(r'Appendix\s+([A-M](?:\.\d+)*)', en))
refs |= set(re.findall(r'\(([A-M]\.\d+)\)', en))
unres = sorted(r for r in refs if r not in supheads)
chk('正文引用附录 %d 个，未解析 %d' % (len(refs), len(unres)), not unres,
    ('未解析: %s | 附录标题: %s' % (unres, sorted(supheads))) if unres else '')
chk('补充材料附录 A–M 齐全', set('ABCDEFGHIJKLM') <= set(h.split('.')[0] for h in supheads),
    str(sorted(set(h.split('.')[0] for h in supheads))))

# ---------- D. N2 搬出内容仍在附录 ----------
print('\n[D] 主文搬出内容仍在附录（新增断言 N2）')
MOVE = [('五分类名', 'answer_zero'), ('api_error 出分母', 'excluded from the denominator'),
        ('MD5 文件级去重', 'MD5'), ('条件身份行级去重', 'identity of the experimental condition'),
        ('逐 tile 解析', 'per tile'), ('238 条分歧', '238')]
bad_move = [n for n, s in MOVE if s not in sup]
chk('附录 B 承接搬出内容 %d/%d' % (len(MOVE) - len(bad_move), len(MOVE)), not bad_move, str(bad_move or ''))
chk('主文 §3.6 已指向附录 B.1–B.2', 'Appendix B.1–B.2' in en)

# ---------- E. 禁用串与语言 ----------
print('\n[E] 禁用串与语言纯净度')
BAD = [(r'⚠', '⚠'), (r'已撤回', '撤回'), (r'\bA\d{1,2}\b', '内部编号'), (r'\bv\d+\b', '版本号'),
       (r'PaperB_', '内部文档'), (r'[A-Za-z]:\\', '盘符'), (r'/root/', '服务器路径'),
       (r'pod_mirror', '内部机器名'), (r'盲审|六模型|七模型', '评审语'), (r'TODO|TBD|XXX', '占位'),
       (r'本节为待实验内容', '占位符'), (r'见\s*与|详见；', '悬空连接词')]
bad = {n: len(re.findall(p, en)) for p, n in BAD if re.findall(p, en)}
zh_res = len(re.findall(r'[\u4e00-\u9fff]', en))
chk('禁用串全 0', not bad, str(bad or '全 0'))
chk('中文残留 0', zh_res == 0, '%d' % zh_res)
chk('补充材料禁用串全 0', not [p for p, n in BAD if re.findall(p, sup)], '')
sup_zh_res = len(re.findall(r'[\u4e00-\u9fff]', sup))
chk('补充材料中文残留 0', sup_zh_res == 0, '%d' % sup_zh_res)

# ---------- F. 数字溯源 ----------
print('\n[F] 数字溯源（不得新造数字）')
nums = lambda s: set(re.findall(r'\d+(?:[.,]\d+)*', s))
en_flat = set(x.replace(',', '') for x in nums(en))
zh_flat = (set(x.replace(',', '') for x in nums(zh)) | set(x.replace(',', '') for x in nums(au))
           | set(x.replace(',', '') for x in nums(ar))
           | set(x.replace(',', '') for x in nums(e1n)))
WHITE = set(str(i) for i in range(0, 103))
ARXIV = set(x for x in nums(en) if re.fullmatch(r'\d{4}\.\d{4,5}', x))
# 结构性 token：章节号/附录号（从英文稿自身标题导出，不硬编码）
SECT = set()
for m in re.finditer(r'^#{2,4}\s+(\d+(?:\.\d+)*)(?=\s)', en, re.M):   # 数字标题，如 "### 3.9 "
    SECT.add(m.group(1))
for m in re.finditer(r'§\s*(\d+(?:\.\d+)*)', en):                      # 正文交叉引用，如 "(§3.1)"
    SECT.add(m.group(1))
# 书写等价的数字（附出处；每一条都写明为什么不是新造数字）
EQUIV = {
    # 中文定稿写「约 62 万条记录」（骨架 L13/L71/L80/L429），英文写 620k —— 同一量、同一出处
    '620': '中文「62 万」的英文写法（骨架 L13/L71/L80/L429）',
    # §7.3 的 0.07 是**推导值**：p≈0.008 是 9 个枚举分割点上的最小值 ⇒ 最小可校正值 ≈ 0.008×9。
    # 该句由 2026-09-20 的 v0487 轮评审（glm53flash）指出后补写，故不在中文定稿里。
    '0.07': '§7.3 多重校正后的最小可校正 p（= 0.008 × 9 个枚举分割点），2026-09-20 补写',
}
missing = sorted((en_flat - zh_flat) - WHITE - ARXIV - SECT - set(EQUIV), key=lambda s: -len(s))
chk('无法溯源的数字 token 0 个', not missing, str(missing[:12]))
print('      （白名单：0–102 结构数 %d；章节号 %d 个；书写等价 %d 条）'
      % (len(WHITE), len(SECT), len(EQUIV)))
for k, v in EQUIV.items():
    print('      EQUIV %s ← %s' % (k, v))

# ---------- G. 篇幅（以实测为准；折算仅作参考） ----------
print('\n[G] 篇幅：实测优先，折算仅参考')
MEAS = os.path.join(ROOT, 'measurement.json')
w = W(en)
# 边界修正：正文 = `## References` 之前。原写法 W(en) − W(References…Appendix C) 会把
# 参考文献**之后**的 Appendix C 指针段算进正文（8,507 vs 正确 8,371，差 136 词）。
_i_ref = en.find('## References')
main_w = W(en[:_i_ref])
refs_w = W(en[_i_ref:en.find('## Appendix C')])
print('  折算参考：正文 %d 词 ≈ %.1f 页；含参考文献 %d 词 ≈ %.1f 页（折算不作合规判据）'
      % (main_w, main_w / 255.0, main_w + refs_w, (main_w + refs_w) / 255.0))
if not os.path.exists(MEAS):
    chk('页数已实测', False, 'measurement.json 缺失——页数必须实测，不接受折算')
else:
    mdj = json.loads(io.open(MEAS, encoding='utf-8', newline='').read())
    pv = mdj['variants'].get('7.5cm') or mdj['variants'].get('none')
    pages = pv['pages']
    ctl = mdj.get('positive_control', {})
    chk('测量有效性（阳性对照）', bool(ctl.get('responded')),
        '注入 %s 词：%s → %s 页' % (ctl.get('injected_words'), ctl.get('pages_before'), ctl.get('pages_after')))
    chk('实测页数 ≤ 35（PR 硬规则）', pages <= 35,
        '%d 页（图件 %s cm；A4／单栏／双倍行距／12 pt；表格 9 pt 单倍）' % (pages, pv['fig_cm']))
    _match = mdj['inputs']['en_md5'] == hashlib.md5(en.encode('utf-8')).hexdigest()
    chk('实测输入与当前英文稿一致', _match,
        ('一致（%s）' % mdj['inputs']['en_md5'][:12]) if _match
        else '不一致 ⇒ 英文稿已改，须重跑 measure_pages.py 后重测')
    rg = mdj.get('reference_growth', {})
    if rg:
        print('  参考文献增长实测：27 条=%s 页；35 条=%s 页；45 条=%s 页'
              % (rg.get('refs27'), rg.get('refs35'), rg.get('refs45')))

# ---------- G2. 区间一致性与术语（2026-09-20 由一轮评审抓出的缺陷类别） ----------
print('\n[G2] 区间一致性与术语')
# (a) 区间一致性：正文任何"a–b%"的弃权份额声称，必须**明确限定其适用范围**，
#     且附录 J.1 的表不得出现超出该范围的互斥读数。
#     教训：正文写 82–94%，而附录 J.1 列了 95.7/98.4/99.4% —— 评审 gemini38flash 一眼抓出。
_occ = [m for m in re.finditer(r'82–94%', en)]
_scoped = [m for m in _occ if 'base contract arm' in en[max(0, m.start() - 400):m.end() + 400]]
chk('正文每处 82–94% 都标注了 base 臂限定', len(_occ) > 0 and len(_occ) == len(_scoped),
    '%d 处，其中带限定 %d 处' % (len(_occ), len(_scoped)))
chk('附录 J.1 声明 82–94% 的适用范围', 'Scope of the 82–94% headline' in sup)
chk('附录 J.1 仅列 canonical 主运行（派生重跑已排除）', 'canonical primary runs only' in sup)
chk('附录 J.1 给出全臂真实区间（含 42.5% 与 99.4%）', '42.5%' in sup and '99.4%' in sup)
# (b) 术语：`class` 不得同词两义（六个旋钮 vs 四个侧）
chk('已消除 "four classes"（应作 four sides）', 'four classes' not in en)
chk('已消除 "six knob classes"', 'six knob classes' not in (en + sup))
chk('附录 F.2 标题与表头用 knobs/side', 'The six knobs, their sides, and their spans' in sup
    and '| Family | Knob | Side |' in sup)

# ---------- G3. 负锚点：改掉的错话不得回来（2026-09-20 依 21 手册 §9.3） ----------
# 手册禁止把旧措辞列成负锚点，是因为**它的**审计语料含内部记录（记录按设计保留旧措辞）。
# 本项目校验语料只有送审件（en/sup），不含记录 ⇒ 负锚点安全，且正是防线。
print('\n[G3] 负锚点（已修正的错话不得回来）')
BANNED = [
    ('0.092 / 0.049 / 0.029', '无源的数字三元组（τ=0.5 的 pred/gt，实为别处的量）'),
    ('at $\\tau = 0.5$ the ratio of', '把"ladder 最高值"误标为"τ=0.5"的旧句'),
    ('four classes and ten units', '同词两义（应作 four knob sides）'),
    ('six knob classes', '同词两义（应作 six knobs）'),
    ('| Family | Knob | Class |', '与"四个侧"冲突的旧表头（应作 Side）'),
]
for _s, _why in BANNED:
    _hit = _s in en or _s in sup
    chk('已移除「%s」' % _why, not _hit, '命中位置：%s' % ('en' if _s in en else ('sup' if _s in sup else '无')))

# ---------- G4. 附录算术对账（2026-09-20 由 v0487 轮 3 份评审的"三行除法"逼出） ----------
# 既有断言只查"字符串在不在"，**没有一条做算术对账**，于是 J.1 两张表口径不一致（分解表取派生重跑、
# S 表取主运行）在我们的守卫下全绿通过，却被三份评审各自用三行除法当场证伪。
# ★ 本段循环变量一律加前缀 `_`：首发版本用 `w` 作循环变量，**遮蔽了全局词数 `w`**，
#   于是摘要行印出"英文稿 0 词"——同族（变量遮蔽）在本会话已出现三次。
print('\n[G4] 附录 J.1 算术对账（分解表 ⇄ 闭式 S ⇄ §5.11(a) 的 gap）')
try:
    _rowre = (r'(?m)^\|\s*([A-Za-z\-]+)\s*\|\s*(-?[\d.]+)%\s*\|\s*(-?[\d.]+)%\s*\|'
              r'\s*(-?[\d.]+)%\s*\|\s*(-?[\d.]+)%\s*\|\s*([\d.]+)\s*\|\s*(-?[\d.]+)%\s*\|')
    _rows = re.findall(_rowre, sup)
    chk('分解表可解析（含 w 与 ρ_ans 列）', len(_rows) >= 4, '%d 行' % len(_rows))
    _bad = []
    for _ds, _rt, _ab, _an, _tot, _wv, _rav in _rows:
        _rt, _ab, _an, _wv, _rav = (float(x) for x in (_rt, _ab, _an, _wv, _rav))
        if abs((_ab + _an) - _rt) > 0.02:
            _bad.append('%s 加法 %.2f+%.2f≠%.2f' % (_ds, _ab, _an, _rt))
        if abs(-(1 - _wv) * 100 - _ab) > 0.05 or abs(_wv * _rav - _an) > 0.05:
            _bad.append('%s w/ρ_ans 与分量不符' % _ds)
    chk('分解表逐行算术自洽（加法 + w/ρ_ans 反推）', not _bad, '；'.join(_bad[:3]) or '各行全对')
    _S = re.findall(r'(?m)^\|\s*Qwen3-VL-32B / ([A-Za-z\-]+)\s*\|\s*([\d.]+)%\s*\|', sup)
    _smap = {k.lower(): float(v) for k, v in _S}
    _mis = []
    for _ds, _rt, _ab, _an, _tot, _wv, _rav in _rows:
        _wv, _rav = float(_wv), float(_rav)
        if _rav >= 0:
            continue
        _sc = (1 - _wv) / (1 - _wv * (1 + _rav / 100)) * 100
        for _k, _v in _smap.items():
            if _ds[:4].lower() in _k or _k[:4] in _ds.lower():
                if abs(_sc - _v) > 0.6:
                    _mis.append('%s 闭式 %.1f vs 表 %.1f' % (_ds, _sc, _v))
    chk('闭式 S 与 S 表同值', not _mis, '；'.join(_mis[:3]) or '一致')
    _gaps = re.findall(r'\*\*(61\.3|57\.5|40\.6) pp\*\*', en)
    chk('§5.11(a) 的 gap 保留（61.3/57.5/40.6）', len(_gaps) >= 3, '%d 个' % len(_gaps))
    # J.4 行数**只在 J.4 段内**数（首发版本用全附录正则，把别处的 32B 行也数进来 ⇒ 6 数成 8）
    _i4 = sup.find('### J.4')
    _j4 = sup[_i4:sup.find('## Appendix K', _i4)] if _i4 > 0 else ''
    _j4rows = len(re.findall(r'(?m)^\|\s*32B\s*/', _j4))
    _wmap = {'six': 6, 'seven': 7, 'eight': 8}
    _div = re.findall(r'across the (\w+) such pairs', en)
    chk('§8.1 的 pairs 计数与 J.4 表行数一致',
        bool(_div) and _wmap.get(_div[0]) == _j4rows and _j4rows > 0,
        '§8.1=%s，J.4 %d 行' % (_div[0] if _div else '?', _j4rows))
except Exception as _e:
    chk('G4 算术对账可执行', False, '异常：%s' % _e)

# ---------- H. 补充材料 ----------
print('\n[H] 补充材料')
sw = W(sup)
print('  补充材料 %d 词；md5 %s' % (sw, hashlib.md5(sup.encode('utf-8')).hexdigest()[:12]))
print('  英文稿   %d 词；md5 %s' % (w, hashlib.md5(en.encode('utf-8')).hexdigest()[:12]))
# 上限从 4600 提到 5400：v0487 轮具名迁出把正文细节搬进补充材料（这是迁移的目的），
# 而 **PR 补充材料本身无页数上限** —— 这条只是可读性的软守卫，不是期刊规则。
chk('补充材料 ≤ 9000 词（软守卫；PR 对补充材料无页数上限，本轮搬入附录 M.7–M.12）',
    sw <= 9000, '%d 词' % sw)

# ---------- I. 投稿包同步 ----------
print('\n[I] 投稿包同步')
for src, dst in [(EN, os.path.join(PKG, '06_英文稿_EN.md')),
                 (SUP, os.path.join(PKG, '08_英文补充材料_Supplementary.md'))]:
    if os.path.exists(dst):
        same = io.open(src, encoding='utf-8', newline='').read().replace('\r\n', '\n') == \
               io.open(dst, encoding='utf-8', newline='').read().replace('\r\n', '\n')
        chk('同步 %s' % os.path.basename(dst), same, '' if same else '内容不一致，需重建投稿包')
    else:
        chk('同步 %s' % os.path.basename(dst), False, '文件不存在')

print('\n' + '=' * 100)
print('失败 %d 项%s' % (len(fails), ('：' + '；'.join(fails)) if fails else ' ✓ 全过'))
print('=' * 100)
sys.exit(0 if not fails else 1)
