# Abstention dominates the aggregate under-count: signed error direction in object counting with vision-language models

---

## Abstract

Object counting is deployed under asymmetric costs, yet evaluation reports symmetric error magnitudes,
for which counting 100 objects as 50 and as 150 are indistinguishable. This paper treats the **signed
error direction** as a measurable dimension, and establishes a more fundamental result: for the
open-weight vision-language models studied here — four configurations across two lineages, one of them dominant (§8.2) — the dominant failure on dense scenes is **not underestimation
but abstention**, answering a literal "0", which accounts for **82–94%** of the total under-count under the ground-truth-weighted share
**(base contract arm**; §3 (*per-cell table in Appendix J.1*).1; both conventions are reported throughout, and Proposition 2 shows
why they must be).
Its expression channel is configuration-dependent: **1591/1591** calls abstain explicitly
once the prompt offers an abstention option, and forbidding abstention yields **2.463–9.452×**
over-estimation rather than zeros (§5.7, Appendix M). Abstention is a
behaviour, not a capability ceiling: it is gated by per-instance legibility rather than object count,
its expression channel is lineage-specific (complete for Qwen, ~70% for InternVL), it can be switched off by tiling (**56.6% → 1.1%**; 2×2: 6.0%), and removing it by prompt relaxation costs direction
($\rho$: **−82% → +234%**). As a supporting result, the achievable span of the direction is an empirical
property of {implementation × training domain × data domain × protocol} rather than of a paradigm: across
official implementations of one task, domain and protocol the span differs by **2–3.4×**
(DM-Count [1] **20.1–34.3 pp** vs P2PNet [2] **10.1 pp**; *readings in Appendix K*), and the same detection architecture differs by **3.5×**
under a training-domain swap alone; a defective reproduction of a third architecture reaches
far larger spans, which we report as the cost of an **implementation defect** rather than as a paradigm
difference (§6.1).

---

**Keywords:** object counting; vision-language models; abstention; signed error direction; evaluation protocol; legibility

## 1. Introduction

**Motivation and the evaluation gap.** Object counting is used in surveillance and resource scheduling,
where the costs of the two error directions are **asymmetric**: missing objects and double-counting are
not equivalent, and most safety and inventory settings prefer over- to under-counting. The **signed direction** of the error has therefore remained
implicit. Our first question is: *can the error direction of a counting system be manipulated
systematically, and what determines the range over which it can be moved?* (*The per-cell numbers in this paragraph are in Appendix M.11.*)

**A more fundamental finding.** Before answering that, we examined a widely accepted premise: that
vision-language models (VLMs) systematically underestimate dense scenes, which prior work treats as a
**capability** problem. Re-classifying every outcome in our corpus (892 result files, ~**620k** records,
four VLM configurations, nine datasets), we find that **the dominant component of these
"underestimates" is not underestimation but abstention**: the model declines to estimate instances it
cannot individually ascertain, and expresses that refusal as the **literal answer "0"**. Under a ground-truth-weighted convention, answering 0 accounts for **82–94%** of the total under-count
(**base contract arm**; over all arms and domains the share spans 42.5–99.4%, §5.5).

The distinction changes three things. **Nature**: abstention is a **behaviour**, not a capability
ceiling, and is therefore switchable from the input side. **Measurement**: it must be reported
**separately**, since otherwise a refusal is read as a *conservative estimate* — the misreading this
paper corrects. **Cost**: removing it is not free, and we quantify the directional price.

**Why separating the two is not a matter of terminology.** Suppose a model answers a literal 0 on 60% of
dense images and underestimates by 20% on the rest. Conventional aggregation reads as *mild
underestimation* — "limited capability with a tolerable direction" — whereas the actual behaviour is that
on six images in ten it produces **no estimate at all**. The remedies are opposite: the former calls for
retraining or calibration, the latter for changing the **input protocol**. Worse, recording a refusal as
"predicted 0" makes it **masquerade as conservative**, and conservatism is what a safety deployment least
wants to correct.

**The second half of the gap.** Selective prediction and abstention-aware classification have
well-developed criteria, but they sit in **classification, question answering and reasoning**, where
abstention is **explicitly declared**. Counting differs in three ways: abstention is **implicit** (a
literal 0, indistinguishable at the output level from an estimate of zero); costs are **asymmetric**, so
its acceptability is a deployment question; and there is **no dependable confidence** on which to build a
rejection rule. The framework cannot be transplanted directly — abstention must first be
**operationalised and that operationalisation validated** in the counting domain (§3.6, Proposition 1) —
and it was this step that exposed the problem with the received reading.

**Four properties of abstention (main results).**

**① Measurable, with a lineage-specific expression channel.** Rather than stipulate that `pred = 0`
means abstention, we give an **empirical criterion**: if a lineage abstained mainly in natural language,
its ratio of answered-zero to textual refusal would approach 1.

**② Gated by per-instance legibility, not by target count**, and **decoupled from directional bias**:
on count-controlled grids, arrangement and blur alone drive abstention from 0% to 90%, while on clean
synthetic dots the base arm never abstains yet still underestimates by **20–43%**, and in microscopy
abstention is **0.0%** with a bias of **−50.1%** (§5.6, §5.7).

**③ Switchable from both ends**, because it is a behaviour: tiling (**Fig. 1**) drops the ShanghaiTech-A [3] abstention rate from **56.6%** to **1.1%** (2×2: 6.0%)
without harming direction.

**④ Removing abstention costs direction.** Prompt relaxation (**Fig. 3**) also drives abstention to zero but flips
$\rho$ from **−82%** to **+234%…+345%**, so **accuracy and directional controllability cannot both be
obtained**; tiling is the only mechanism that improves both.

*(The per-property numbers behind these four statements are collected in Appendix L; each is also stated where it is first used, in §5.)*

**Supporting result: the response spectrum of direction.** The signed direction can be moved
continuously, but its **achievable span is an empirical property of {implementation × training domain ×
data domain × protocol}, not of a paradigm**. A bootstrap and permutation analysis (§7.3) supports **one separable low-response
cluster** (VLM pixel budget, ≤ 22.4 pp, $p \approx 0.008$) alongside an **internally continuous
high-response spectrum** (33.5–150.7 pp); we explicitly do **not** claim two anchor zones or bimodality. (*Full detail in Appendix M.17.*)

**Contributions.**

1. **Establishing abstention as a first-class indicator in counting evaluation, with a reproducible
   operationalisation** (§3.6, Appendix B): mutually exclusive classes, de-duplication protocols, a
   per-lineage empirical criterion identifying abstention with an answered zero (Proposition 1), and a
   reporting triad. Its consequence is narrower than a revision of the literature: **within the Qwen cells studied here, literal-zero outputs dominate the pooled under-count** (Proposition 4 makes the dominance an identity once those outputs are read as abstention, so the empirical content is that they are frequent and that they behave like abstention), and abstention is a **switchable behaviour** rather than a fixed property. Switching is not only input-side: the channel through which abstention is expressed is set by the output contract, so an answered zero is a property of the serving configuration rather than of the lineage (§5.7). We do **not** claim the revision of the field's judgement "VLMs underestimate dense scenes" for vision-language models in general: for InternVL2.5-8B [5] the answered-zero channel covers only 69.69% of abstentions (§3.6, Proposition 7), and the corpus is dominated by one lineage (§8.2).
2. **Per-instance legibility: a pre-inference diagnostic and its explicit limits.** We give the proxy,
   the effect structure under three controlled manipulations, and what it **cannot** do: it supports
   selective prediction (the most legible 20% of images reduce MAE by **31–66%**) but **cannot repair
   direction** ($\rho$ attenuating only from **−85.0%** to **−53.4%**), and because it requires
   instance-level boxes it is a **diagnostic, not a deployment-time criterion**.
3. **An empirical response spectrum for direction, with a re-checkable measurement discipline**: the dual
   convention and its divergence condition (Proposition 2), the anomaly-exclusion rule, span variants
   against the noise floor (**2.15–6.46 pp**), and **three negative methodological results** — calibration
   cannot remove the achievable span; "whether the direction can cross zero" is a convention-dependent
   weak criterion while "span" is robust; and **no predictor of span magnitude exists**, including the
   candidate we propose and reject ourselves (Proposition 3).

**Scope, and what we do not claim.** The abstention results rest on **four open-weight VLM configurations
across nine datasets**; the direction results span **three families of implementations**. We do **not**
evaluate the exemplar/few-shot family, do **not** cover proprietary models, do **not** claim that any
evaluated system counts accurately, do **not** claim the three paradigms can be classified by knob type,
and — most importantly for reading the rest of the paper — do **not** claim the existence of a quantity
that predicts span magnitude, since that is a hypothesis we test and reject ourselves. The paper is best
read as a **measurement report**: it establishes measurable dimensions, gives their boundaries, and
labels explicitly what cannot be established. §3.8 states the formal content; §4–§7 give the evidence; §8 states the limitations.

## 2. Related Work

### 2.1 Detection-based counting versus density regression

Two families dominate counting: detection-based methods localise instances and count them, while density
regression predicts a density map whose integral is the count — the definitional formulation of the field
(Lempitsky & Zisserman, 2010). Comparative work treats them as paradigms with characteristic trade-offs,
but **never treats signed error direction as a dimension of comparison**: paradigms are ranked by
magnitude error, so a method that systematically over-counts and one that systematically under-counts can
be reported as equivalent. §7.3 supplies that comparison and finds the paradigm label to be a weak
predictor of span compared with the implementation itself.

### 2.2 Thresholds, operating points and cost-sensitive decisions

The detection literature has long studied the operating point, and cost-sensitive decision theory
formalises asymmetric losses. Our contribution is to **import the operating point into counting error
direction** as a measured quantity: NMS IoU is a second such knob, and "crossing zero" is not a single
event, because the zero of the user-side error and that of the total error differ by a factor of about
2.1–2.3 (§4.4, §4.7).

### 2.3 VLM counting, and abstention as an absent framework

VLM counting is an active area, with benchmarks showing that current models count poorly ([6] and
successors). A parallel and largely separate literature studies abstention: selective prediction [7],
rejection options, abstention benchmarks for multimodal reasoning ([8], [9]), and
abstention knobs in video question answering ([10]). **The gap is that abstention rates have never
been measured on counting tasks**, and that the intuitive "count threshold" explanation for refusal is
falsified here: abstention is gated by per-instance legibility rather than by object count, and for the
dominant lineage it appears not as a textual refusal but as a literal zero (§3.6).

### 2.4 Decoupled heads and cascade errors

A line of work decomposes counting error into components and studies propagation between them, in the density-regression tradition founded by [11].

*(Full detail in Appendix A.)*
### 2.5 A same-source study: numerosity stimuli under orthogonal manipulation

The numerosity tradition [12] and NumerosityVLM [13] likewise use synthetic stimuli under orthogonal manipulation to evaluate seven
VLMs. It is methodologically cognate with our synthetic part but **answers a different question**:

**Table 2.** Positioning against the numerosity-stimulus literature of §2.5.

| Dimension | NumerosityVLM | This work |
|---|---|---|
| Stimuli | Synthetic, orthogonally manipulated | Synthetic **and** real; pixel budget, blur, contrast, crowding, tiling, prompt |
| Dependent variable | **Accuracy** | **Signed error direction and abstention** |
| Conclusion | Architecture explains most variance | Direction is governed by {implementation × training domain × data domain × protocol} |

### 2.6 Sparse counting and the head/person granularity problem

Sparse counting benchmarks (SFCHD [14], FSC-147 [15], CountBench [16], TallyQA [17]) [18] and the head/person literature supply
our sparse and external-validity settings. Recent work notes that **counting granularity is left
implicit** — a target may be an identity, an attribute, an instance type, a category or an abstract
concept — and that most counting datasets lack multi-granularity annotation ([19]; [20]). §3.2 turns this into a first-class variable.

### 2.7 VLM counting-failure mechanisms: narrowing our own positioning

Recent work establishes, with evidence stronger than ours, that counting failure occurs at the
**reporting** stage rather than the perceptual stage ([21]; a hierarchy in [22]), and PairTally
([23]) has established cross-paradigm counting comparison. We therefore **demote** our own earlier
framing of the first finding to a **cited premise**, and state our contribution as: *consistent with
[21] and [22], this paper supplies behavioural, cross-paradigm, signed-direction evidence.*
Three boundaries follow: the dependent variable differs (accuracy versus signed direction and abstention);
the data differ (everyday scenes versus aerial, synthetic-microscopy and dense-crowd scenes); and the
contrast design differs (we pair in-domain against zero-shot weights and control the input protocol).

### 2.8 Evaluation validity: non-determinism and aggregate metrics

Our VLM indicators initially came from single samples. Repeat sampling shows that item-level
reproducibility for a hosted API is only about **15%**, while a locally controlled stack agrees at
essentially 100%, and that aggregate quantities are far more stable. 

*(Full detail in Appendix A.)*

### 2.9 Crowded-scene occlusion counting

A dedicated benchmark evaluates VLMs on counting occluded objects (CAPTURe [24]). Its objects
remain **informative** behind the occluder and require inference, so it probes reasoning; our occlusion
factor asks instead whether an instance is still **ascertainable** given a pixel budget. The models do **not** perform
modal completion: when inference is possible they neither infer nor abstain, they simply under-report as
usual (−50% vs. −50%). (*The per-cell numbers in this paragraph are in Appendix M.11.*)

## 3. Method

### 3.1 Counting conventions and metrics

Calibration conventions and their failure modes follow the standard taxonomy of Guo et al. [25].

All three families are evaluated against the same ground truth. Magnitude metrics are MAE, RMSE,
normalised MAE and tolerance-based scores; the principal **directional** quantity is the signed relative
deviation

$$\rho \;=\; \frac{\overline{\text{pred}} - \overline{\text{gt}}}{\overline{\text{gt}}}
\quad\text{(in percent, signed),}$$

which has **two sub-conventions that must be labelled separately** — the **pooled ratio** and the
**per-image ratio mean** — whose divergence condition is given by Proposition 2. Correlation coefficients
are always written $r$ and annotated as Pearson or Spearman. **Abstention** is an indicator in its own
right, never folded into tolerance-based scoring, and always reported as a **triad**: the rate, $\rho$ on
answered items only, and the abstention share of the total under-count. Density is summarised by OPM,
whose applicability boundary is §7.1. The statistical protocol and the non-determinism declaration are in
Appendix A.

### 3.2 Target granularity is a first-class, and widely ignored, variable

In counting, "one target" is not naturally determined: in a safety-helmet scene an annotation may define
the **head** or the **whole person**, and recent work notes that granularity is usually left implicit
([19]; [20]). Running both conventions on SFCHD shows that **changing the convention
changes the sign and magnitude of the conclusion** (§5.2). **Any counting evaluation must therefore
declare its target granularity explicitly**; part of the spread across published counting numbers is a
granularity artefact rather than a modelling difference.

### 3.3 Per-instance legibility: definition, operationalisation and boundaries

Our central independent variable is **per-instance legibility** — whether, under the given observation
conditions, a target instance is still sufficient to be judged an independent instance. It is **not a
property of the model** but of {observation conditions × annotation granularity}, and can therefore be
computed **before inference** from images and annotations.

**It is a multivariate construct; we do not assume a single sufficient proxy.** The three manipulable
factors are **instance size**, **blur** $\sigma$ (decoupled from resolution) and **overlap** (arrangement
at fixed size and blur). Their effects are **not equal**: under controlled frame pairing **blur is the
strongest single gate** (blur 9.1% vs. downsampling 0.6%, **+8.6 pp**), while the **per-instance pixel
budget is a covariate rather than the gate** — informative within a domain, but at fixed scale it
co-varies with instances per image, and across the aerial and microscopy domains the two decouple (§5.6,
§5.10).

**The observable proxy.** For each instance $i$, take $a_i$, the pixels inside its annotation box **not
covered by another instance's box**; the image-level proxy is the median over instances,
$p = \operatorname{median}_i a_i$ (Appendix C.1).

**Boundaries — claims we do not make.** The proxy supports **stratification, ranking and selective
prediction**. It is **not** a sufficient statistic, must **not** be compared across scales directly, and
must not be read as "more pixels is always better". Because it requires instance-level boxes it is a
**diagnostic, not a deployment-time decision rule**. It is also **not** an attention map or a confidence,
and **not** OPM, whose cross-domain Spearman correlation is only **+0.33** (Appendix C.3).

### 3.4 Datasets and scene characteristics

FSC-147 is the counting-anything benchmark of Ranjan et al. [15]; CountQA [26] and PushupBench [27] are the corresponding VLM-counting benchmarks.

Nine datasets are characterised on **two** axes rather than one — the count axis (OPM) **and** the
legibility axis (full table in Appendix D.3). The observation that matters for the central claim is that
VisDrone [28] and AI-TOD [29] have the **lowest** targets-per-image (17–22, far below every "count threshold" one
might posit) yet abstain **as often as** ShanghaiTech-A, which has 433 targets per image: 68% vs. 57%.

### 3.5 Implementations

**Detection:** YOLOv12n [30] (slicing-aided tiling follows SAHI [31]) with nine variants plus budget × source-domain combinations, zero-shot COCO [32] person detectors under a tiling protocol for the dense end, and two label conventions; Faster R-CNN [33] and
RetinaNet [34] (for the tiling ladder) supply a second and third detector family. Fairness parameters per family are in Appendix D.2. (*The per-cell numbers in this paragraph are in Appendix M.11.*)
Instruct [35] on a self-hosted 4-bit AWQ [36] stack cross-checked against a BF16 hosted API, with an 8B scale
control, a Qwen2.5-VL-7B [37] generation control and InternVL2.5-8B [5] as a second lineage; three directional arms
use **byte-identical prompts across datasets**, plus five prompt families and a seven-level
prompt-strength dose. **Density regression:** BL [38], CSRNet [4] and DM-Count [1] trained on SFCHD [14], with public
in-domain weights for the dense end.

### 3.6 Abstention: operationalisation and lineage stratification

Abstention is our leading indicator, so its operationalisation is stated item by item rather than left as
"the predicted total is zero". **Appendix B** carries the full protocol; three points matter here.

**(a) Five mutually exclusive classes** — `normal`, `answer_zero`, `refuse`, `format_drift`, `api_error` —
with `api_error` excluded from the denominator. **(b) De-duplication** at file level (MD5) and at row level
by **identity of the experimental condition**, **not** by item. The class criteria, the de-duplication
protocol and the per-tile parsing of concatenated `raw` fields are given in Appendix B.1–B.2.

**(c) Is `pred = 0` a sufficient operationalisation? A lineage-stratified answer.** We give an empirical
criterion rather than a stipulation: if a lineage abstained mainly in natural language, its ratio of
answered-zero to textual refusal would approach 1 (Proposition 1). Over the whole corpus (892 result
files, ~620k records):

**Table 1.** Lineage-stratified abstention channel (the table behind §3.6(c) and Proposition 1).

| Lineage | Answered zero | Textual refusal | Ratio | Coverage by `pred = 0` |
|---|---|---|---|---|
| Qwen3-VL-32B [35] | 31,387 | 57 | **550.6 : 1** | **99.82%** |
| Qwen3-VL-8B | 3,392 | 0 | — (none) | **100%** |
| Qwen2.5-VL-7B | 980 | 0 | — (none) | **100%** |
| **InternVL2.5-8B** | 14,015 | **6,096** | **2.3 : 1** | **69.69%** |

**For the Qwen family — the source of all our abstention headlines — `pred = 0` is a complete
operationalisation** (refusals are 0.18%, 0% and 0%). **For InternVL2.5-8B it covers only about seven
tenths**, the rest arriving as textual refusals. **Cross-lineage comparisons of abstention rate must
therefore define the channel per lineage.**

**(d) A consequence that supplies mechanistic evidence.** Refusals are **gated by whether the prompt
demands per-instance enumeration**: under prompts requiring "count one by one" or "locate every person",
models refuse explicitly; under prompts permitting an overall estimate, explicit refusals are essentially
absent. This is **first-person evidence** that abstention is triggered by loss of per-instance legibility,
where §3.3 offers only proxy manipulations (verbatim wordings, cross-lineage encoding differences and the
scope note on a superseded ratio in Appendix B.3–B.5).

### 3.7 Anomalous records, exclusions and data hygiene

Anomalous predictions (`pred ≥ 1e5`, plus one exact sentinel) are removed before any rate is computed; a
corpus-wide scan shows a **single** anomalous item can move a row's headline figure by hundreds of
percentage points, so this is a precondition rather than a refinement. Records whose key data could not be
read are quarantined and counted rather than silently dropped. Where a comparison depends on matching
annotations — detector boxes whose class set includes vehicles while the ground truth counts people only —
we recompute under a person-matched convention and report both.

### 3.8 Formal framework: what is identifiable from outputs

**Proposition 1 (abstention is not identified by outputs alone).** Let a system map an input to a reported
value $y \in \{0\} \cup \mathbb{Z}_{>0} \cup \{\bot\}$. Two distinct latent events — the model *abstains*,
and the model *estimates zero* — both produce $y = 0$. The output therefore does **not** identify
abstention, and identification requires an **auxiliary channel** that reacts differently to the two
events. We use $\kappa = \#\{y = 0\} / \#\{\text{textual refusals}\}$; the identifying condition is
the lineage under study has a **large** $\kappa$ (we treat the criterion as operational rather than asymptotic: a lineage is usable when almost every abstention is expressed as an answered zero, and we report the measured $\kappa$ rather than asserting identification in the limit). **Corollary:** the paper's abstention headlines are
identified for the Qwen family ($\kappa = 550.6$, 0.18% contamination) and **not** for InternVL2.5-8B
($\kappa = 2.3$, 30.31%), which is why §3.6 reports the two separately rather than pooled.

**Proposition 2 (the two conventions diverge exactly when the per-image ratio correlates with ground
truth).** With $r_i = (p_i - g_i)/g_i$, the pooled convention is the $g$-weighted mean of $r$ and the
per-image convention its unweighted mean, so

$$\rho_{\text{pooled}} - \bar\rho = \frac{\operatorname{Cov}_g(g, r)}{\overline{g}}.$$

The two coincide **iff** the per-image ratio is uncorrelated with ground truth, and the divergence has
the sign of that covariance. Because abstention is itself GT-dependent (§5.11(b)), the covariance is
non-zero in dense domains by construction — which is why both are always reported here.

**Proposition 3 (span is a functional of the admitted level set).** For levels $\ell = 1,\dots,L$ with
ratios $q_\ell$, $\text{span} = 100\,(\max_\ell q_\ell - \min_\ell q_\ell)$. Two consequences: (i) any
candidate predictor built from $\max_\ell q_\ell$ or $\min_\ell q_\ell$ is a **component of the
definition**, and conditioning on the other extreme gives a partial correlation of **exactly $\pm 1$** —
which is what we observe for our own candidate (Appendix F.3) and why we withdraw it; (ii) **availability**
*is* decidable from the same quantities, since it holds iff $\max_\ell q_\ell \ge 1$ at the loosest
admitted level. The paper's position is therefore deliberately asymmetric: **availability is a decidable
property of observable quantities; magnitude is not predicted by any quantity we have been able to
construct.**

**Proposition 4 (the aggregate bias decomposes exactly).** Let $G=\sum_i gt_i$ over all items, and let
$G_N$ and $P$ be the ground truth and the predicted total over the **answered** items ($pred_i>0$), with
$w=G_N/G$. Since an abstained item contributes $pred=0$,
$$\rho_{\text{total}}=w\,(1+\rho_{\text{answered}})-1=-(1-w)+w\,\rho_{\text{answered}},$$
an identity rather than an approximation. **(i)** The aggregate under-count is therefore exactly an
**abstention term** $-(1-w)$ plus a **scaled answering term** $w\,\rho_{\text{answered}}$, which makes the
separation asserted in §5.7 a matter of construction rather than of observation. **(ii)** The abstention
share of the under-count has the closed form $S=(1-w)/[1-w(1+\rho_{\text{answered}})]$ — a function of two
observables and nothing else, and the identity behind the **82–94%** (base contract arm) of §5.5. The proof, the verification
over 95 result files, and the scope boundary are in Appendix J. **Scope:** the decomposition requires an
**additive** (ground-truth-weighted) convention and fails under the per-image-median convention — the
quantitative reason both conventions are reported, complementing Proposition 2.

**Proposition 5 (span is equivariant, not invariant, under shared affine calibration).** For
$c(q)=a+s\,q$ with $s>0$ applied to every admitted level of a unit,
$\text{span}(c\circ q)=s\cdot\text{span}(q)$. A fitted slope must therefore accompany every reported span,
and the objection that a large span is a calibration artefact **requires exhibiting $s\ll1$**, since an
affine calibration compresses a span by at most the factor $s$. Non-affine recalibration lies outside the
proposition and can compress spans, which is why the quantile map is classed as undeployable.

**Proposition 6 (targets-per-image is not a legibility-consistent stratifier).** Call a stratifying
variable $X$ *legibility-consistent* if the order it induces refines the legibility order. Then
targets-per-image $M$ is **not** legibility-consistent. VisDrone and AI-TOD have the lowest $M$
(17–22) and ShanghaiTech-A has $M=433$, yet abstention is comparable (68% vs. 57%); with abstention
monotone in legibility — which §5.6 supports causally — the two orders disagree on this pair. $\qed$ A
candidate stratifier must thus pass *monotonicity of abstention in it*; correlation with legibility alone
does not suffice, and this is what licenses stratifying by legibility rather than by OPM.


**Proposition 7 (the identification error of the answered-zero channel is exactly $1/(\kappa+1)$).** Let a
lineage express every abstention through one of two channels only: an **answered zero** or a **textual
refusal**, and let $f$ be the fraction of abstentions that take the refusal channel. The measured
answered-zero count then estimates the true abstention count with **relative error exactly $f$**, and since
$\kappa = (1-f)/f$ by definition, $f = 1/(\kappa+1)$. Two consequences. **(i)** The error is a *known
function of a measured quantity* — it needs no assumption about which images are abstained on, only that
the two channels are exhaustive. **(ii)** It makes the cross-lineage comparison quantitative rather than
qualitative: the abstention rate of a lineage with $\kappa$ is identified to within $1/(\kappa+1)$, so the
paper's headline rate is identified to **0.18%** for Qwen3-VL-32B ($\kappa = 550.6$) and to **30.31%** for
InternVL2.5-8B ($\kappa = 2.3$) — which is precisely why §3.6 reports the two lineages separately instead of
pooling them, and why the scope note of §8.2 is a consequence of the arithmetic rather than a hedge.
**Scope:** the proposition is conditional on the two-channel exhaustiveness; a third channel (e.g. a
non-numeric answer counted as a refusal) would change $f$, which is why Appendix B.3 states the unified
criterion explicitly.

**Proposition 8 (the dual-convention gap is bounded by the abstention mass).** From Proposition 4,
$\rho_{\text{total}} - \rho_{\text{answered}} = -(1-w)(1+\rho_{\text{answered}})$, hence
$$\lvert \rho_{\text{total}} - \rho_{\text{answered}}\rvert \;\le\; (1-w)\,(1 + \lvert\rho_{\text{answered}}\rvert),$$
where the inequality is the exact identity restated with $\lvert\rho_{\text{answered}}\rvert$: it holds with
**equality if and only if** $\rho_{\text{answered}} \ge 0$, so for every cell measured here (all of which
have $\rho_{\text{answered}} < 0$) the identity $\lvert\rho_{\text{total}} - \rho_{\text{answered}}\rvert =
(1-w)\,(1+\rho_{\text{answered}})$ applies exactly while the $\lvert\rho_{\text{answered}}\rvert$ form is strict. The gap therefore **vanishes if and only if** either there is no abstention ($w = 1$) or the answered
subset reports zero ($\rho_{\text{answered}} = -1$); note that an *unbiased* answered subset
($\rho_{\text{answered}} = 0$) does **not** remove it — the gap is then exactly $-(1-w)$ — so it cannot be
removed by any change to the answering behaviour alone. Verified over the four dense and aerial
domains under the base arm: the bound gives 40.6–61.3 pp and the observed gaps are
**61.3 / 57.5 / 40.6 / 40.6 pp**, i.e. the bound is attained to rounding (Appendix J.5). This is the
quantitative reason a single-convention report is not merely incomplete but *uninterpretable*: the size of
the convention effect is a function of the abstention mass, which the report is trying to measure.

### 3.9 Figures and tables

Figures **1–4** (cited below as Fig. 1–Fig. 4, each at the point where its claim is stated) are carried in the main text because each supports a claim stated there: the
abstention-versus-tiling mechanism figure, the four-panel separation of the two failure modes, the
prompt-strength dose–response, and the threshold-cleaning curve. 

*(Full detail in Appendix D.)*

## 4. Results I: Detection — the threshold knob and the domain conditionality of its reach

### 4.1 Reachability of the zero crossing, and its domain conditionality

Detection is the only family here in which a **single scalar** moves the signed direction continuously
across zero: on VisDrone the in-domain detector's pooled $\rho$ travels from **+507.4%** to **−0.9%**, a
span of **508 pp**, while the same architecture with COCO-pretrained weights covers only
**16.4 / 30.3 / 55.5 pp** and never crosses. It is a usable availability test,
but **not** a predictor of how large the span will be (§7.3). (*The per-cell numbers in this paragraph are in Appendix M.9.*)

### 4.2 Refinement by density binning: the bound holds, but it is a per-tile bound

An earlier reading of these results placed the boundary of reachability at a fixed image-level
density. Refining by ground-truth density bin, on a fine grid (threshold step 0.005, bootstrap 10,000×),
shows the bound is real but **belongs to each effective tile rather than to the image**: the last
reachable bin is reached by tiling, and what fails beyond it is the per-tile instance budget. This
converts an unexplained ceiling into a design rule.

### 4.3 The fine $\tau$ ladder: where the boundary lies

To rule out a coarse-grid artefact we repeat the scan on a **fine grid** — $\tau$ from 0.02 to 0.90 in
steps of 0.005 (**177 points**), with **3,000× bootstrap image resampling** for the 95% interval of
$\tau^\*$; every weight file is matched to a unique result table by an `n_raw` fingerprint (**100%
match**), so configuration attribution does not rest on file naming. Tiling moves UCF from
unreachable to reachable ($\tau^\*$ 0.121–0.152): protocol and threshold jointly determine
reachability. (*The per-cell numbers in this paragraph are in Appendix M.9.*)

### 4.4 A second knob: NMS IoU and input scale

The threshold is not the only quantity bearing on reachability. Changing the **NMS IoU** on the same
tiled configurations moves $\tau^\*$ monotonically from **0.038** (IoU 0.5) through **0.073** (0.6) to
**0.121** (0.7) — **NMS IoU is a second knob determining reachability** (Appendix E.2). Changing the
inference input scale matters much less: at 640 / 1024 / 1280 the values are **0.117 / 0.121 / 0.131**.
Directional controllability in detection is therefore not a property of one scalar but of the **joint**
configuration of threshold, NMS IoU and input protocol.

### 4.5 Tile granularity: a third knob, which can turn unreachable into reachable

Extending the ladder to **tile-512 and tile-256** across **two detector families** under the identical protocol (full table in Appendix E.3) gives two readings. First, **tile granularity can rescue an unreachable configuration** — a domain unreachable at tile-1024 becomes reachable at tile-512 — so unreachability is a **joint property of {domain × protocol}**, not of the domain. Second, **the two families unseal at different granularities**: the pre-FPN architecture needs finer tiling than the other to unseal the same domain. (*Per-cell values in Appendix M.16.*)

### 4.6 The direction of $\tau^\*$ under finer tiling is not family-invariant

The intuition "finer tiles raise $\tau^\*$" holds for RetinaNet — monotone increasing on both UCF-QNRF [39]
(0.124 → 0.225 → 0.306) and ShanghaiTech-A (unreachable → 0.124 → 0.237) — and **fails** for YOLO, which
is non-monotone on both (UCF 0.121 → 0.176 → 0.173; ShanghaiTech-A unreachable → 0.260 → 0.183).

*(Full detail in Appendix E.)*
### 4.7 "Crossing zero" must specify which zero

The phrase presumes the zero is unique; it is not. **The cascade identity holds exactly per image**, $\max\lvert\delta_U - (\delta_T - \delta_H)\rvert =
0$ over 6,033 images: the decomposition is a **definitional identity**, and any two of the three
quantities determine the third. (*The per-cell numbers in this paragraph are in Appendix M.9.*)

## 5. Results II: Vision-language models — abstention is the leading failure mode

### 5.1 Screening and the full SFCHD cross-paradigm comparison

Screening on the sparse end (SFCHD, 12,066 images) across three arms and two stacks establishes the
baseline for the rest of the section: on sparse, clearly visible targets, the three-arm prompts move the
direction as expected but at small amplitudes, and abstention is negligible. The dense and aerial
domains, where the effects of interest live, are the subject of the remaining subsections.

### 5.2 Target granularity changes the sign and magnitude of the conclusion

Running both target conventions on SFCHD (head-level versus whole-person) under the three directional
arms shows that $\rho$ and the abstention rate are **not interchangeable** between conventions. The
consequence is stated as an independent conclusion: any counting evaluation must declare its target
granularity, otherwise numbers are not comparable across studies. This also means that a part of the
spread across published counting numbers is a **granularity artefact** rather than a modelling
difference.

### 5.3 Sparse-domain three-arm directional induction

On the full sparse set (12,066 items × 3 arms × 2 stacks) the prompts move the direction monotonically
and reproducibly, with the *under* arm producing systematic under-counting and the *over* arm
over-counting. Because abstention is near zero here, this setting isolates **directional** control from
**abstention** control — a separation that proves useful in §5.7.

### 5.4 Cross-domain abstention summary

Aggregating over domains, the abstention rate is **not** ordered by object count. It is highest in the
dense-crowd and aerial domains (ShanghaiTech-A 56.6%, VisDrone 68.2%, AI-TOD 68.1%) and essentially
zero in the clearly-resolved domains (ShanghaiTech-B 0%, sparse sets near 0%), while ShanghaiTech-B has
**more** targets per image (124) than VisDrone (22). Object count is therefore not the ordering
variable; §5.6 identifies what is.

### 5.5 Decomposing the under-count: abstention versus answering

By **Proposition 4** the total under-count is an abstention term plus a scaled answering term, and the
abstention share has the closed form $S=(1-w)/[1-w(1+\rho_{\text{answered}})]$; evaluated here it gives **82–94%** on the four dense and aerial domains **under the base contract arm** (82.1–94.2%). **This is the quantitative core of the paper's central claim: the received
description "VLMs underestimate dense scenes" is mostly a description of refusals.** (*The per-cell numbers in this paragraph are in Appendix M.9.*)

### 5.6 Causal attribution of abstention: not count, but legibility

Three controlled manipulations refute the intuitive "too many objects" explanation. The gate is **per-instance legibility** (§3.3); count retains only a secondary within-domain
modulating role. (*The per-cell numbers in this paragraph are in Appendix M.11.*)

### 5.7 Abstention and under-counting are two separable failure modes

**The title's universal reading is already excluded by our own data.** Reading it as "under-estimation does not happen" would require $\lvert\rho_{\text{answered}}\rvert$ inside the paper's own **7 pp** band (§8.1); the measured values are **−19.8%**, **−29.2%** and **−39.6%**. The title therefore claims the **composition of the aggregate under-count**, not the absence of under-estimation.

**Mode A: capacity-driven under-counting.** Even with ideal input the model under-counts by **20–43%**,
the bias growing with the count — a floor set by the reporting stage, not by perception.

**Mode B: mode collapse, whose extreme form is answering 0.** Triggered by loss of legibility, absent on
clean input, switchable on by blur, overlap or a strict prompt.
**The channel is set by the output contract (E1):** on the items that the corpus configuration
answered exactly 0, four further configurations given an explicit abstention option abstained
explicitly in **1591 of 1591** successful calls and **never** answered 0, while forbidding abstention
produced a median of **2.463–9.452×** the true count. The zero therefore does not require the
quantised local deployment, and is not a universal family behaviour either: the hosted checkpoint
matching the corpus configuration answers 0 on **25.8–31.7%** of these items, whereas `plus`, `flash`
and `235b` answer 0 on **0–0.4%**. The zero therefore does not require
the quantised local deployment, and is not a universal family behaviour either. Appendix M gives all
48 cells. (*The per-cell numbers in this paragraph are in Appendix M.11.*)


**The two modes decouple completely (Fig. 2).** On clean synthetic dots the base arm **never abstains** yet still
under-counts by **20–43%**; in microscopy (BBBC005 [40]) abstention is **0.0%** while the bias reaches **−50.1%**.
Conversely, on dense crowds abstention is 50–70% while the answered-only bias is only −19.8% / −29.2%.
Independent causes, independent cures.

**A three-way corroboration of the floor.** The synthetic-grid floor, microscopy (abstention off, bias
on) and real images restricted to the answered subset all land in **−18% to −29%** — the **capacity
floor**, independent of abstention and of resolution. (*Per-cell values and the onset count are in
Appendix J.7.*)

**Legibility is a usable selector, but cannot repair direction.** Keeping the most legible 20% reduces MAE
by **31–66%** while the relative deviation only attenuates from **−85.0%** to **−53.4%** — still a
systematic under-count of more than half (selector AUC **0.753–0.786**). **Legibility decides *whether* to
answer, not *which way* to be wrong.** What gates abstention is **blur, not resolution**: downscaling to
15% of the pixels gives almost no abstention (**0.6%**) whereas blurring the *same* image and frames gives
**9.1%** (**+8.6 pp**, paired, $n = 900$).

### 5.8 The two routes to removing abstention, and their price

**Route A — tiling (raise legibility; preserves accuracy)** reduces the ShanghaiTech-A abstention rate from **56.6%** to **0.0%** while leaving direction intact, and lifts the suppressed directional authority
of prompts in the aerial domain (+13.9% whole-image to **+160.4%** at 3×3). It is the only mechanism here
that improves both accuracy and directional controllability. This is a **hard trade-off**:
**accuracy and directional controllability cannot both be obtained.** (*Per-level detail in Appendix M.8.*) (*The per-cell numbers in this paragraph are in Appendix M.11.*)

### 5.9 Model scale: what is bought is knowing whether to answer

Comparing 8B and 32B models of one lineage (a clean 4× contrast), scale does not make answers more
accurate: the 8B model's answered-only relative deviation is **more negative** (*numbers in Appendix M.8*). **Scale buys knowing whether to answer, not directional
controllability.** (*Amplitude and span factors in Appendix L.1.*) (*The per-cell numbers in this paragraph are in Appendix M.11.*)

### 5.10 Aerial domain: the legibility extreme

VisDrone and AI-TOD are the legibility extreme. Tiling gives limited relief (*numbers in Appendix M.8*): **the aerial bottleneck is instance
under-resolution, the crowd bottleneck is overlap**, and the two respond differently to the same
intervention. The contract effect is only partly effective: lowering the pixel budget raises
abstention monotonically in both lineages, but "forbid 0" works only partly for Qwen and hardly at all
for InternVL (*per-cell values in Appendix C.4*). (*The per-cell numbers in this paragraph are in Appendix M.11.*)

### 5.11 Three quantitative consequences of abstention



**(a) Counting abstentions as zero inflates "under-estimation", so a dual convention is required.** On the same data the pooled relative deviation differs between "abstentions counted as 0" and "answered items only" by **61.3 pp** (ShanghaiTech-A), **57.5 pp** (UCF) and **40.6 pp** (AI-TOD and VisDrone)
(*per-domain values in Appendix M.8*).

Proposition 4 expresses this gap as $-(1-w)(1+\rho_{\text{answered}})$, so the four reported values are a **consistency check on the numbers printed in this paper** rather than an independent empirical prediction.

**(b) The abstention rate rises with ground truth, and (c) the scale effect is domain-dependent.** Both are quantitative statements whose per-cell tables and worked numbers now live in Appendix J.6; the two conclusions are: the slope of the deviation-vs-ground-truth relation **reverses sign** between conventions, and a 4× parameter increase enlarges the directional span by **2.5–3.1×** in the dense domains but not in the aerial domain (**0.66–1.18×**). *(Full detail in Appendix J.6.)*
## 6. Results III: Density regression — direction is a function of the input-scale protocol

### 6.1 Density regression has a scale freedom parameter that must be calibrated per domain

On the dense end, density regression is the most accurate family under a fixed protocol but the least
directionally controllable: its predicted totals scale multiplicatively with inference input size, so
$\rho$ is a function of the scale protocol rather than of the model alone, and the family carries a
**scale freedom parameter that must be calibrated per domain**. Because a reproduction of CSRNet required
us to retire an implementation defect, all density-regression span figures here use the **official
DM-Count weights** on the identical item set and grid: **20.1–34.3 pp**, not the 107–1433 pp of the
retired reproduction.

### 6.2 Three further properties, and their protocols

Three further properties of this family matter for measurement, with protocols in **Appendix H**: a
counting-consistency term on the log ratio between the predicted integral and the ground-truth count
reduces the seed-to-seed spread by roughly an order of magnitude and removes most of the systematic
positive offset the uncorrected objective leaves behind — a **remedy for a training artefact**, not a new
architecture (H.1); the abstention rate is a stable property **only under greedy decoding**, since under
sampling it co-varies with temperature and sample count, which is why our VLM protocol fixes temperature
at 0 (H.2); and the collapse of density-regression output under overlap occurs for both 8B and 32B models
at comparable overlap levels, making it a property of the task structure rather than of model capacity
(H.3).

## 7. Discussion

### 7.1 Legibility, not OPM, is the stratifying variable

The conventional density axis conflates "how many objects are there" with "how hard is each one to
ascertain". Across ten domain/dataset points the correlation between abstention rate and object count is
only $r = +0.33$, with no explanatory power, whereas the legibility proxy orders the same points
consistently. Later work should stratify by per-instance legibility, and — given §3.3 — state explicitly
that the proxy is a diagnostic rather than a deployment-time criterion.

### 7.2 Same-scale accuracy comparison across the three families

Bringing the three families to a common effective instance scale inverts the usual ranking (full table in
Appendix F.1). A single density-regression
number is not a comparable quantity unless the weight set is specified. (*The per-cell numbers in this paragraph are in Appendix M.11.*)

### 7.3 The response spectrum of knobs, and its statistical structure

Assembling the six knobs with their isotonic-calibrated spans (Appendix F.2, and the per-unit table of
Appendix F.9) refutes the claim that knobs divide by side of action: the vision-side tiling level
reaches **28.6 pp**, the same order as the language-side contract at **26.8 pp**.

**Statistical structure.** For the ten (knob × domain) units we took the isotonic-calibrated span with its
3,000× bootstrap interval and enumerated **all** single split points (Appendix F.3). We therefore report the separable low-response cluster as a **candidate structure** rather than an
established partition, and we claim **one separable low-response cluster** (VLM pixel budget, ≤ 22.4 pp)
alongside an **internally continuous high-response spectrum** (33.5–150.7 pp) — and explicitly **not**
two anchor zones or bimodality, since with four knob **sides** collapsed into ten units a bimodality
test has very low power. (The six knobs of Appendix F.2 map onto four sides; the split-point enumeration of Appendix F.3 runs over
the ten units, not over the six knobs — the two counts are different populations, and the word "class" is
not used for either.) (*The per-cell numbers in this paragraph are in Appendix M.9.*)

**Calibration cannot remove the achievable span.** By **Proposition 5** an affine calibration scales a span
by its slope, so compressing one requires $s\ll1$; held-out shared affine calibration leaves large spans
largely intact, and the only family that compresses span in a deployment-relevant way is the quantile map,
which needs the ground-truth distribution and is therefore **not deployable** — the direct answer to the
objection that span is a calibration artefact. **Span is also not a single construct**, since endpoint
spans derive most of their magnitude from one extreme level and the mean absolute deviation is a
different quantity (*per-unit values in Appendix F.8*). The noise floor is **2.15–6.46 pp**.

**An availability criterion exists; a magnitude predictor does not.** "Is `pred/gt ≥ 1` at the lowest
threshold?" predicts reachability with **zero exceptions** across three lineages and nine cells. But no
quantity predicts *how large* the span will be, and our own candidate is tautological (Proposition 3).
For a paper organised around an axis, having no predictor for that axis is a structural weakness, and we
state it as such.

### 7.4 The high response of the detector threshold is domain-conditional

The detector threshold is the largest-response knob, but its authority is **domain-conditional**: in the aerial domain the full in-domain ladder moves $\rho$ across the whole span, whereas in dense-crowd domains **no lineage reaches `pred/gt ≥ 1` at any threshold** and the span collapses close to the noise floor; the same architecture and knob give a **3.5×** smaller span under a training-domain swap alone (*per-cell values in Appendix M.8*).

### 7.5 Saturation slope: a same-lineage scale difference, verified two ways

Across the four configurations of one lineage the slope of the density-saturation relation is
$-0.00511$ to $-0.00382$ (range 0.00129, 27.5% relative); the three configurations that agree at about −0.005 do so as a cluster, with the 8B point as the outlier. 

*(Full detail in Appendix F.)*

### 7.6 Language-side contracts: channel independence, and one excluded branch

The per-arm numbers quoted below are labelled by (model × domain × contract arm × convention) in Appendix G.1; each is a pooled relative deviation on the common item intersection.

Two facts survive. **`choice` rewrites the value without passing through abstention**: it moves the relative deviation across zero while the abstention rate barely moves, and it works in dense domains too. One correction: on the `choice` arm the 32B model shows a pooled deviation of
only +0.9%, but the grid's value 50 sits close to that domain's median GT (50.5) and 46.6% of answers land
on it — **a property of the grid design, not calibration**. (*The per-cell numbers in this paragraph are in Appendix M.11.*)

### 7.7 Three mechanism hypotheses, tested and excluded

To explain the strong directional effect of `forbid0` we tested three explanations; **all three are
excluded.** **Mediated effect — no**: tiling drives the 32B abstention rate from **56.6%** to **1.1%**
with the effect nearly unchanged (**+185 → +195 → +167 pp**), and 8B at **0.0%** abstention still shows
**+24 to +40 pp**, so abstention rate is not the mediator and the magnitude is governed by the domain. (*Full detail in Appendix M.16.*)

*(Full detail in Appendix G.)*

### 7.8 The quantitative structure of relative deviation

Per-level means and medians disagree at the sparse end for every configuration, and the disagreement is a
**magnification** rather than a shift; only Qwen3-VL-8B assigns the correct direction to all three curves
at magnified scale, consistent with its computed statistics. 

*(Full detail in Appendix A.)*

### 7.9 Deployment implications: legibility as a nominal operating range

The legibility score can be read as a criterion for **"is this input still inside the model's nominal
operating range?"**, consistent with a requirement forming independently in the perception literature,
where detectors fail silently under blur, noise, compression and resolution change, so that predicting
without judging whether the input is in the nominal range is insufficient ([41]; also [42]),
and where safety-critical perception is expected to carry abstention with statistical guarantees
([43]). **Legibility can decide whether to answer;
changing the direction requires changing the protocol, the prompt, or the family.** (*The per-cell numbers here are in Appendix M.14.*)

### 7.10 An independent endorsement of enumeration over regression

Our finding that enumeration-style counting is more directionally controllable than regression-style
counting is not isolated: work on other tasks has independently reached the same conclusion that
regress-then-round pipelines lose the property being measured. 

*(Full detail in Appendix F.)*

### 7.11 A reporting-norm recommendation

Three concrete requirements for cross-paradigm counting comparison follow, stated as recommendations
rather than findings. 

*(Full detail in Appendix F.)*

## 8. Limitations

### 8.1 Disclosure of measurement fragility




**Two runner defects, and one dead parse branch.** Two defects in the measurement runners were found
and are disclosed in full in Appendix I.2; both affect only the collection path, not the reported
aggregates. A third instrument finding belongs with them for the same reason: the corpus runner's
structured-JSON branch never fires, because its pattern omits the quote before the key, so every stored
value came from its first-integer fallback. We audited all **2,496** rows of the three-arm prompt experiment (**832** items x 3 arms) and the two readings
agree in **100%** of them, so the finding has **zero** measured impact (Appendix M.6).

**Run-to-run non-determinism.** Nondeterminism in this regime is documented for LLM inference [44], [45] and for evaluation harnesses [46], [47]. With temperature 0 under 4-bit AWQ the per-image disagreement rate is
**22–27%** while the aggregate change in ME stays within **0.19** counts; for a hosted API, item-level
reproducibility falls to roughly **15%**. Where the corpus contains an independent re-run of the same
configuration, the aggregate $\rho$ differs by at most **0.81 pp** across the six such pairs
(Appendix J). Aggregate conclusions are robust; per-image conclusions must be
read against the noise band, and differences below **7 pp** are treated as indistinguishable.

**Graded isolation with a residue ledger.** Some remote result files were unavailable during collection
because of server-side errors. We isolate the affected runs in graded tiers and keep a ledger of exactly
which items were affected and which analyses were recomputed without them, so a reader can reverse the
cleaning (Appendix I).

**A census of anomalous predictions, with forced exclusion.** A single anomalous item can move a row's
headline figure by hundreds of percentage points; in one family each dataset contained **exactly one**
such item, which fully explained that row's apparent effect. Values at or above `1e5`, and one exact
sentinel, are excluded everywhere, with filtered and unfiltered values reported where material.



**No attention-based criterion**, since attention sharpness is very nearly uninformative about correctness
($R \approx 0.001$). **Per-cell intervals are lower bounds**: they resample images and therefore
under-state the uncertainty from the small number of levels within a cell.

### 8.2 Scope limitations

**The optimal input fidelity was not located.** We show that legibility drives abstention at the low end
and that abstention can be switched off from both ends, but we did not measure whether **increasing**
fidelity beyond the native scale becomes harmful — a non-monotonicity that existing work suggests may
exist.

**The attribution boundary is behavioural, not anthropomorphic.** We read an answered zero as **mode
collapse** — output degenerating onto the mode or a prior integer — not as a human-like refusal. Where
models produce explicit refusals the wording is suggestive, but we claim nothing about intent, and the
operationalisation is stated so that it can be replaced.

**The detector lineage is narrow**, resting primarily on YOLO with RetinaNet and Faster R-CNN as secondary
lineages; a broader architectural sweep would establish whether §4.1's domain conditionality and §4.5's
unsealing granularity are family or architecture properties. We likewise do not evaluate the
exemplar/few-shot family (§7.6 states a prediction for it rather than a result).

**The abstention identification rests on a two-channel assumption, which the discriminating experiment
now tests (§5.7, Appendix M).** Proposition 1 shows that an answered zero does not identify abstention
from outputs alone, and Proposition 7 quantifies the residual error **under the assumption that
abstentions are expressed only as answered zeros or as textual refusals**. That assumption is testable:
on the items the corpus answered 0, offering an explicit abstention option produced **1591/1591**
explicit abstentions and no zeros, and forbidding abstention produced best estimates at a median of
**2.463–9.452×** the true count — so on that subset the third channel is excluded. Two limits remain.
First, the re-query varies weight precision **and** serving engine together (a local 4-bit
compressed-tensors deployment against a hosted endpoint), so it shows that the channel is
configuration-dependent without isolating which of the two causes it. Second, the subset is selected
for being answered 0, so a genuine estimate of zero outside it is not excluded, and the corpus-wide
contamination rate therefore remains bounded by the two-channel argument rather than measured.
Appendix B.3 states the unified channel criterion explicitly so that the assumption can be replaced
wherever it is still load-bearing.

**The corpus is dominated by one lineage, which bounds every frequency claim.** Of the ~620k records
the majority come from the Qwen family, so the abstract's and title's abstention finding is a claim
about that family and about the configurations measured alongside it, not about vision-language models
in general (we cover four open-weight configurations, two lineages, and no proprietary model).
This is acceptable for the abstention headlines — which is why §3.6 confines the completeness claim to
that family — but the cross-lineage comparisons rest on a smaller InternVL subset.

**Domain composition is not systematic**: the nine datasets were assembled to span a legibility range
rather than sampled from a stated population, so domain-level statements describe these domains and are
not estimates over a distribution.

**The corpus was not pre-registered as a whole.** Only the sub-experiments explicitly marked as
pre-registered had their criteria written before the data were examined; the rest are post hoc, including
the choice of tiling level, weight set and aggregation convention. We mitigate this by reporting both
conventions wherever they diverge and the weight-set range rather than a single value, but we do not claim
the post hoc parts are free of this exposure.

**Statistical power for the spectrum is low** (four knob sides, ten units); the separated-cluster claim rests
on a permutation test over single split points plus bootstrap intervals, not on a modality test.

## 9. Conclusions

We set out to make the **direction** of counting error measurable, and found that the dominant failure on
dense scenes is not a directional error but abstention. The contributions are therefore two. The first is a
**measurement dimension**: signed error direction, reported together with the convention under which it is
read, because the two conventions differ by tens of percentage points on the same data. The second is a
**behavioural reading of the answered zero**: the channel through which a model declines to answer is set by
the output contract rather than by the lineage, so a zero is a property of the serving configuration
(§5.7). The strongest part of the evidence is the cross-configuration and cross-paradigm replication of the
span spectrum; the weakest parts are stated as such in §8, and the most consequential open question is
whether the abstention channel can be given a statistical guarantee rather than a measured rate (§7.9).

## Declaration of generative AI and AI-assisted technologies in the manuscript preparation process

During the preparation of this work the author(s) used a panel of large language models, accessed through their vendors' application programming interfaces, in order to conduct simulated peer review of the manuscript and to audit the internal consistency of the reported numbers and cross-references. These tools were not used to generate the text. The author(s) reviewed and edited the content as needed and take(s) full responsibility for the content of the published article.

## Data availability

The image corpora are public datasets, cited above. The derived per-image
prediction records, analysis scripts and run logs that reproduce every reported
number are available from the corresponding author on request.

## Funding

This research did not receive any specific grant from funding agencies in the public, commercial, or
not-for-profit sectors.

## References

1. Zhang, Y., Zhou, D., Chen, S., Gao, S., Ma, Y. Single-Image Crowd Counting via Multi-Column Convolutional Neural Network. CVPR 2016. https://doi.org/10.1109/CVPR.2016.70..

2. Wang, B., Liu, H., Samaras, D., Nguyen, H. Distribution Matching for Crowd Counting. NeurIPS 2020. preprint arXiv:2009.13077.

3. Song, Q., Wang, C., Jiang, Z., et al. Rethinking Counting and Localization in Crowds: A Purely Point-Based Framework. ICCV 2021. https://doi.org/10.1109/ICCV48922.2021.00335..

4. Li, Y., Zhang, X., Chen, D. CSRNet: Dilated Convolutional Neural Networks for Understanding the Highly Congested Scenes. CVPR 2018. https://doi.org/10.1109/CVPR.2018.00120..

5. Chen, Z., Wang, W., Cao, Y., et al. Expanding Performance Boundaries of Open-Source Multimodal Models with Model, Data, and Test-Time Scaling. preprint arXiv:2412.05271, 2024.

6. Guo, X., Huang, Z., Shi, Z., et al. Your Vision-Language Model Can't Even Count to 20: Exposing the Failures of VLMs in Compositional Counting (VLMCountBench). preprint arXiv:2510.04401, 2025.

7. Srinivasan, T., Hessel, J., Gupta, T., et al. Selective "Selective Prediction": Reducing Unnecessary Abstention in Vision-Language Reasoning. Findings of ACL 2024. preprint arXiv:2402.15610.

8. Madhusudhan, N., Yadav, V., Lacoste, A. Knowing When Not to Answer: Evaluating Abstention in Multimodal Reasoning Systems. preprint arXiv:2604.14799, 2026.

9. Pramono, F., Cai, J., Kulkarni, S. TRAPSBench: Vision-Language Models Encode but Fail to Express Epistemic Restraint. COLM 2026. preprint arXiv:2608.13167.

10. Ortiz, J. Explicit Abstention Knobs for Predictable Reliability in Video Question Answering. preprint arXiv:2601.00138, 2025.

11. Lempitsky, V., Zisserman, A. Learning To Count Objects in Images. NIPS 2010.

12. Trick, L. M., Pylyshyn, Z. W. Why are small and large numbers enumerated differently? A limited-capacity preattentive stage in vision. Psychol. Rev. 101(1):80–102, 1994. https://doi.org/10.1037/0033-295X.101.1.80..

13. Fu, Y., Li, F., Liu, X., et al. NumerosityVLM: A Cognitively Inspired Benchmark for Interpreting Numerosity Representations in VLMs. preprint arXiv:2608.15425, 2026.

14. Yu, F.-S., Li, J., Wang, X., et al. Large, Complex, and Realistic Safety Clothing and Helmet Detection: Dataset and Method. preprint arXiv:2306.02098, 2023.

15. Ranjan, V., Sharma, U., Nguyen, T., Hoai, M. Learning To Count Everything. CVPR 2021. preprint arXiv:2104.08391.

16. Paiss, R., Ephrat, A., Tov, O., et al. Teaching CLIP to Count to Ten. ICCV 2023. https://doi.org/10.1109/ICCV51070.2023.00294..

17. Acharya, M., Kafle, K., Kanan, C. TallyQA: Answering Complex Counting Questions. AAAI 2019. https://doi.org/10.1609/AAAI.V33I01.33018076..

18. Djukic, N., Lukezic, A., Zavrtanik, V., et al. A Low-Shot Object Counting Network With Iterative Prototype Adaptation. ICCV 2023. preprint arXiv:2211.08217.

19. Liu, C., Wu, H., Xie, W. Count Anything at Any Granularity. preprint arXiv:2605.10887, 2026.

20. Huang, Z., Dai, M., Zhang, Y., et al. Point, Segment and Count: A Generalized Framework for Object Counting. CVPR 2024. preprint arXiv:2311.12386.

21. El-Shangiti, A., Nurgazy, A., AlQuabeh, H., et al. The Count Is There, but Misaligned: Understanding and Correcting Counting Failures in VLMs. preprint arXiv:2607.09544, 2026.

22. Anh, D., Irawan, P., Vo, T. Counting to Four is still a Chore for VLMs. preprint arXiv:2604.10039, 2026.

23. Nguyen, G., Huang, Y., Hoai, M. Can Current AI Models Count What We Mean, Not What They See? A Benchmark and Systematic Evaluation (PairTally). preprint arXiv:2509.13939, 2025.

24. Pothiraj, A., Stengel-Eskin, E., Cho, J., et al. CAPTURe: Evaluating Spatial Reasoning in Vision Language Models via Occluded Object Counting. ICCV 2025. preprint arXiv:2504.15485.

25. Guo, C., Pleiss, G., Sun, Y., et al. On Calibration of Modern Neural Networks. ICML 2017. preprint arXiv:1706.04599.

26. Tamarapalli, J., Grover, R., Pande, N., et al. CountQA: How Well Do MLLMs Count in the Wild? preprint arXiv:2508.06585, 2025.

27. Li, S., Chen, J., Sharma, K., et al. PushupBench: Your VLM is not good at counting pushups. preprint arXiv:2604.23407, 2026.

28. Zhu, P., Wen, L., Du, D., et al. Detection and Tracking Meet Drones Challenge. IEEE TPAMI 44(11), 2022. https://doi.org/10.1109/TPAMI.2021.3119563..

29. Wang, J., Yang, W., Guo, H., et al. Tiny Object Detection in Aerial Images. ICPR 2021. https://doi.org/10.1109/ICPR48806.2021.9413340..

30. Tian, Y., Ye, Q., Doermann, D. YOLOv12: Attention-Centric Real-Time Object Detectors. NeurIPS 2025. https://doi.org/10.52202/085713-2627..

31. Akyon, F., Altinuc, S., Temizel, A. Slicing Aided Hyper Inference and Fine-tuning for Small Object Detection. ICIP 2022. preprint arXiv:2202.06934.

32. Lin, T.-Y., Maire, M., Belongie, S., et al. Microsoft COCO: Common Objects in Context. ECCV 2014. https://doi.org/10.1007/978-3-319-10602-1_48..

33. Ren, S., He, K., Girshick, R., Sun, J. Faster R-CNN: Towards Real-Time Object Detection with Region Proposal Networks. IEEE TPAMI 39(6), 2017. https://doi.org/10.1109/TPAMI.2016.2577031..

34. Lin, T.-Y., Goyal, P., Girshick, R., et al. Focal Loss for Dense Object Detection. ICCV 2017. https://doi.org/10.1109/ICCV.2017.324..

35. Bai, S., Cai, Y., Chen, R., et al. Qwen3-VL Technical Report. preprint arXiv:2511.21631, 2025.

36. Lin, J., Tang, J., Tang, H., et al. AWQ: Activation-aware Weight Quantization for LLM Compression and Acceleration. preprint arXiv:2306.00978, 2023.

37. Bai, S., Chen, K., Liu, X., et al. Qwen2.5-VL Technical Report. preprint arXiv:2502.13923, 2025.

38. Ma, Z., Wei, X., Hong, X., et al. Bayesian Loss for Crowd Count Estimation with Point Supervision. ICCV 2019. https://doi.org/10.1109/ICCV.2019.00624..

39. Idrees, H., Tayyab, M., Athrey, K., et al. Composition Loss for Counting, Density Map Estimation and Localization in Dense Crowds. ECCV 2018. https://doi.org/10.1007/978-3-030-01216-8_33..

40. Ljosa, V., Sokolnicki, K. L., Carpenter, A. E. Annotated high-throughput microscopy image sets for validation. Nat. Methods, 2012. https://doi.org/10.1038/nmeth.2083..

41. Becker, S., Weiss, S., Hübner, W., et al. Self-Aware Object Detection via Degradation Manifolds. preprint arXiv:2602.18394, 2026.

42. Narasimhan, H., Menon, A., Jitkrittum, W., et al. Plugin Estimators for Selective Classification with Out-of-Distribution Detection. preprint arXiv:2301.12386, 2023.

43. Kumar, D., Darabi, N., Tayebati, S., et al. Beyond Confidence: Adaptive Abstention in Dual-Threshold Conformal Prediction for Autonomous Systems. Proc. 2025 IEEE International Conference on Omni-layer Intelligent Systems. preprint arXiv:2502.07255.

44. Yuan, J., Li, H., Ding, X., et al. Understanding and Mitigating Numerical Sources of Nondeterminism in LLM Inference. preprint arXiv:2506.09501, 2025.

45. Fu, T., Martínez, G., Conde, J., et al. Beyond Reproducibility: Token Probabilities Expose Large Language Model Nondeterminism. IEEE Trans. Comput., 2026. preprint arXiv:2601.06118.

46. Fang, Z., Jiang, Z., Chen, H., et al. Dataset-Level Metrics Attenuate Non-Determinism: A Fine-Grained Non-Determinism Evaluation in Diffusion Language Models. preprint arXiv:2604.13413, 2026.

47. Mustahsan, Z., Lim, A., Anand, M., et al. Stochasticity in Agentic Evaluations: Quantifying Inconsistency with Intraclass Correlation. preprint arXiv:2512.06710, 2025.

## Appendix C (separate supplementary file): migrated detail

Item-level tables, protocols, convention notes and pre-registered criteria moved out of the main text are
provided as a **separate supplementary file**, organised into appendices **A–M**: conventions, metrics and
statistical protocol; the full abstention operationalisation; the legibility proxy; implementations,
fairness and the dataset table; the detection ladders; the span spectrum including the ten calibration
units; the excluded mechanism hypotheses with their pre-registered criteria; density-regression
protocols; the data-hygiene ledger; the proofs and verification for Propositions 4–8; per-property
numbers; and the discriminating experiment on the abstention channel with all 48 of its cells.

This is a **move, not a deletion**: every section whose body was moved retains its heading in the main
text with a one- to two-sentence conclusion and a pointer to the corresponding appendix, so each claim can
be checked against the same rules, protocols and numbers that support it. Where the main text and the
supplementary file disagree, the main text governs.
