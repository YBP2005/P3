# -*- coding: utf-8 -*-
"""按 21 号文收结果：① 文件级完整性（先于内容）② 选每模型最新 ③ 抽取 8 维评分与判定。
判据先行：完整性不过的档位不参与内容判读，单列出来。
"""
import glob
import io
import os
import re
import sys

sys.stdout.reconfigure(encoding='utf-8')
D = r'D:\deepseek\analysis\model_review'
MODELS = ['dsflash', 'dspro', 'glm53flash', 'gemini38flash', 'grok46', 'gpt56sol', 'qwen38max', 'hy4']
DIMS = [('新颖性', 10), ('技术严谨', 20), ('实验充分', 15), ('评估公平', 10),
        ('可复现', 10), ('指标合理', 15), ('统计显著', 10), ('不确定度', 10)]
q = chr(0x3002)  # 。
END_OK = set('.!?' + q + '）)]}"\'*`|')

print('=' * 104)
print('① 文件级完整性（先于内容）')
print('=' * 104)
sel = {}
for m in MODELS:
    cands = [p for p in glob.glob(os.path.join(D, 'm4prime_review_%s_*.md' % m))
             if not p.endswith('.part') and '.part.' not in p]
    if not cands:
        print('%-14s **无产物**' % m); continue
    p = max(cands, key=os.path.getmtime)
    t = io.open(p, encoding='utf-8', errors='replace').read()
    body = re.sub(r'(?s)```.*?```', lambda x: x.group(0), t)   # 保留代码块，仅用于长度
    flags = []
    if len(t) < 500:
        flags.append('过短')
    zh = len(re.findall(r'[\u4e00-\u9fff]', t))
    if zh < 200:
        flags.append('正文中文过少(%d)' % zh)
    last = t.rstrip()[-1] if t.strip() else ''
    if last not in END_OK:
        flags.append('可能截断(末字符=%r)' % last)
    if '量化评分' not in t and '8 维' not in t and '八维' not in t:
        flags.append('**缺评分表**')
    if not re.search(r'(?m)^\|.*新颖', t):
        flags.append('评分表非表格形式')
    sel[m] = p
    print('%-14s %7d B  %5d 中文字  %s' % (m, len(t), zh, ' ok' if not flags else ' ⚠ ' + '; '.join(flags)))
print()
print('② 选中文件（每模型最新时间戳）')
for m, p in sel.items():
    print('   %-14s %s' % (m, os.path.basename(p)))

print()
print('=' * 104)
print('③ 8 维评分抽取（每维取首次出现的 x/满分）')
print('=' * 104)
rows = {}
for m, p in sel.items():
    t = io.open(p, encoding='utf-8', errors='replace').read()
    sc = {}
    for key, full in DIMS:
        pat = re.escape(key) + r'[^\n]{0,80}?(\d+)\s*/\s*(\d+)'
        mm = re.search(pat, t)
        if mm:
            sc[key] = (int(mm.group(1)), int(mm.group(2)))
    total = re.search(r'总分[^\d]{0,12}(\d{1,3})', t)
    sub = re.search(r'(?:专项小计|专项)[^\d]{0,12}(\d{1,3})\s*/\s*35', t)
    veto = re.search(r'否决项[^\n]{0,80}', t)
    dec = re.search(r'判定[^\n]{0,60}', t)
    rows[m] = dict(sc=sc, total=int(total.group(1)) if total else None,
                   sub=int(sub.group(1)) if sub else None,
                   veto=(veto.group(0).strip() if veto else ''),
                   dec=(dec.group(0).strip() if dec else ''))
    got = sum(1 for k, _ in DIMS if k in sc)
    print('%-14s 抽出 %d/8 维%s | 总分 %s | 专项 %s' % (m, got, '' if got == 8 else '  ⚠',
          rows[m]['total'], rows[m]['sub']))
    if got < 8:
        print('     已抽到: %s' % {k: v for k, v in sc.items()})

print()
print('=' * 104)
print('④ 对照表（未抽到的留 —）')
print('=' * 104)
hdr = '%-14s' % 'model' + ''.join('%-9s' % k[:4] for k, _ in DIMS) + '%6s %6s' % ('总', '专项')
print(hdr)
for m in MODELS:
    if m not in rows:
        continue
    sc = rows[m]['sc']
    line = '%-14s' % m + ''.join('%-9s' % (('%d/%d' % sc[k]) if k in sc else '—') for k, _ in DIMS)
    line += '%6s %6s' % (rows[m]['total'] if rows[m]['total'] else '—',
                         rows[m]['sub'] if rows[m]['sub'] else '—')
    print(line)
print()
for m in MODELS:
    if m in rows:
        print('%-14s 否决: %s' % (m, rows[m]['veto'][:80] or '（未抽到）'))
        print('%-14s 判定: %s' % ('', rows[m]['dec'][:80] or '（未抽到）'))
