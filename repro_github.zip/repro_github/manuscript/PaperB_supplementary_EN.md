# Supplementary Material

**Abstention, Not Underestimation: Signed Error Direction as a Measurable Evaluation Dimension in
Object Counting**

> This file contains the methodological detail whose conclusions are stated in the main text. It is a
> **move, not a deletion**: every section whose body was moved retains its heading in the main text
> with a one- to two-sentence conclusion and a pointer here, so that each claim can be checked against
> the same rules, protocols and numbers that support it. Where the main text and this file disagree,
> the main text governs.

---

## Appendix A. Conventions, metrics and statistical protocol

### A.1 Metric definitions

Magnitude metrics are MAE, RMSE, normalised MAE, and tolerance-based scores
($\text{tol} \le 1$, exact match, $P(\text{over})$). The signed relative deviation is

$$\rho \;=\; \frac{\overline{\text{pred}} - \overline{\text{gt}}}{\overline{\text{gt}}}
\quad\text{(in percent, signed),}$$

computed under two sub-conventions: the **pooled ratio** (means taken separately in numerator and
denominator) and the **per-image ratio mean**. Equation (1) of the main text and Proposition 2 state
their relation. An anomalous-prediction rule applies throughout: records with `pred ≥ 1e5`, and the
exact sentinel value 1234567890, are removed before any rate is computed (Appendix H).

Density is summarised by **OPM**, objects per megapixel; §7.1 gives its applicability boundary.

### A.2 Statistical protocol

Bootstrap with 10,000 resamples under block resampling by image; paired Wilcoxon tests; Holm
correction for multiplicity. Where a per-cell span is reported, the bootstrap interval resamples
images, which **under-states** the uncertainty contributed by the small number of levels within a
cell; the intervals are therefore lower bounds on uncertainty rather than calibrated coverage
statements.

### A.3 Non-determinism and the noise band

Aggregate and per-image stability differ sharply, and we declare this rather than discover it. With
temperature 0 under 4-bit AWQ, the per-image disagreement rate is **22–27%**, while the aggregate change
in ME stays within **0.19** counts. Magnitude and direction conclusions at the aggregate level are
therefore robust, whereas per-image conclusions must be read against the noise band. For a hosted API,
item-level reproducibility falls to roughly **15%**, whereas a locally controlled stack at batch ≤ 2
agrees at essentially 100% for the same configuration. Consequently, model-to-model differences below
**7 pp** are treated as indistinguishable throughout, and one difference that flips under repetition is
not reported at all. The noise floor derived from repeated sampling is **2.15–6.46 pp**, and is used as
such in §7.3.

---

## Appendix B. Abstention: full operationalisation

### B.1 The five mutually exclusive classes

For every record we read both the pipeline's declared columns (`zero`, `refuse`, `abstain`, `error`) and
values re-derived from `pred`, `parse_ok` and `raw`, then assign exactly one class:

| Class | Criterion | Meaning |
|---|---|---|
| `normal` | `parse_ok = 1` and `pred > 0` | Normal answer |
| `answer_zero` | `parse_ok = 1` and `pred = 0` | **The abstention body of this paper** |
| `refuse` | declared `refuse = 1`, or `parse_ok = 0` with a natural-language refusal in `raw` | **Textual refusal** |
| `format_drift` | a response that is neither a number nor a refusal | Format drift |
| `api_error` | HTTP 4xx/5xx, timeout, or insufficient balance in `raw`/`error` | Service failure, **excluded from the denominator** |

The five classes sum to $n$ by construction. Records whose declared and derived values disagree — 238
across the entire corpus — are counted separately and inspected by hand rather than resolved by rule.

### B.2 De-duplication protocol

**File level.** The corpus contains byte-identical mirrors: the same result appears under several
harvest directories. Files are de-duplicated by MD5.

**Row level.** Rows are de-duplicated by **identity of the experimental condition**, not by item,
because the prompt-dose experiment places **the same item at seven strength levels inside a single
file**; item-level de-duplication would compress seven conditions into one row and destroy the design.
The identity is `all columns except the outcome columns`, and when merging we keep the row with
`parse_ok = 1`.

**Tiled rows.** For tiled experiments a single row's `raw` field is a **concatenation of per-tile
answers** (`{"count": a} | {"count": b} | …`). These are parsed per tile and summed; failing to do so
misclassifies the entire row as format drift, which is one of the two reasons an earlier analysis of
ours under-reported format drift as zero.

### B.3 Encoding differences between lineages

In certain file families the column layout differs: `parse_ok` is always 1 and there is no `refuse`
column, and the two lineages encode abstention differently — **Qwen writes `pred = "0"`, InternVL
writes `pred = ""` (empty string)**. We therefore adopt the unified criterion "**`pred` is not a
positive number ⇒ abstention**", which is inconsistent in **zero of 15** files carrying an `abstain`
column. Judging by `pred = "0"` alone would **report InternVL's abstention rate as 0.0%**; the true
values are ShanghaiTech-A **21.4%**, ShanghaiTech-B 0.0%, UCF **28.4%**, AI-TOD **47.8%** and VisDrone
**50.2%**. Note also that answered zeros on sparse images with GT = 1 are mostly **genuine misses**
rather than abstentions, which is why abstention rates are always discussed stratified by GT.

### B.4 The natural-language refusals, verbatim

The refusals are not distributed uniformly across prompt families. They concentrate on prompts that
demand per-instance enumeration; the wording itself names the reason:

> "cannot be counted precisely; the crowd in the image is dense, and individual heads/bodies cannot be
> located one by one."
> "cannot be counted precisely; the crowd is overly dense and partly occluded; the estimated number is
> in the thousands."

Under all prompt families that permit an overall estimate, the explicit refusal count is zero.

### B.5 Scope of the identification argument

The lineage stratification uses the whole corpus. An earlier analysis in this project, run on a smaller
corpus, reported a **global** answered-zero-to-refusal ratio of about 313 : 1 with zero format drift.
On the current corpus that global ratio does not hold — it is **12.1 : 1**, with format drift at about
**1.9%** — for two reasons: the corpus later gained a large number of InternVL results, whose refusal
rate is markedly higher, and the earlier analysis did not parse the multi-tile `raw` of tiled
experiments. **The two lineage-stratified conclusions of §3.6(c) are unaffected**, because they are the
product of the re-computation, not of the earlier ratio. This note is retained rather than removed:
a reader comparing this paper against an earlier version of our own numbers should be able to see
which figure superseded which.

---

## Appendix C. The legibility proxy in full

### C.1 Definition

For each instance $i$, take $a_i$, the number of pixels inside its annotation box that are **not
covered by another instance's box**; the image-level proxy is the median over instances,
$p = \operatorname{median}_i a_i$, in pixels per instance. The proxy requires instance-level boxes,
which is what makes it a diagnostic rather than a deployment-time decision rule.

### C.2 The three factors and their unequal effects

The construct has three directly manipulable factors: **instance size** (scale factor or fixed short
side), **blur** $\sigma$ (a degradation mode decoupled from resolution), and **overlap** (arrangement
on a synthetic grid at fixed size and blur, varying only spacing and packing). Their effect sizes are
not equal. Holding the image and the frames fixed and changing only the degradation mode, downscaling
to 15% of the pixels still produces almost no abstention (**0.6%**), whereas blurring the *same* image
and frames produces **9.1%** — a difference of **+8.6 pp** under paired comparison ($n = 900$). Blur is
therefore the strongest single gate, and the per-instance pixel budget is a **covariate** rather than
the gate: it is informative within a domain because blur and px/obj correlate strongly there, but at
fixed scale it also co-varies with the number of instances per image, and across the aerial and
microscopy domains the two decouple.

### C.3 Why we do not use attention or confidence

Recent mechanistic work shows that attention sharpness is very nearly uninformative about correctness
($R \approx 0.001$). A legibility criterion built on attention would therefore have no grounding, and
ours is computed from images and annotations only.

---

## Appendix D. Implementations, fairness and the dataset table

### D.1 Implementations

**Detection.** YOLOv12n with nine variants plus budget × source-domain combinations; for the dense end,
zero-shot COCO person detectors under a tiling protocol; two label conventions (original and cleaned).
A structurally different detector family — Faster R-CNN, and RetinaNet for the tiling ladder — is used
to separate implementation effects from paradigm effects.

**Vision-language models.** Qwen3-VL-32B-Instruct, primarily through a self-hosted 4-bit AWQ stack and
cross-checked against a BF16 hosted API, with an 8B scale control, a Qwen2.5-VL-7B generation control,
and InternVL2.5-8B as a second lineage. Three directional arms (base/over/under) use **byte-identical
prompts across datasets**; the prompt texts are given verbatim in the accompanying prompt appendix.

**Density regression.** BL, CSRNet and DM-Count trained on SFCHD; public in-domain weights for the dense
end. Where a reproduction is used instead of official code this is marked explicitly, and the
corresponding span figures are reported under the official weights as well.

### D.2 Fairness statement

| Family | Pretraining source | Capacity | Input scale | Notes |
|---|---|---|---|---|
| Detection | COCO and in-domain (VisDrone) | 2.6 M–37 M parameters (YOLOv12n family); RetinaNet R50 | 640 / 1024 / 1280 / 1536 short side | both zero-shot and in-domain weights reported |
| Density regression | ImageNet classification (VGG-16 backbone) | 16.3 M | fixed short side and multiplicative scale ladders | official and reproduction weights reported separately |
| VLM | Qwen3-VL and InternVL2.5 lineages | 7 B / 8 B / 32 B | whole image, tiled (2×2…6×6), pixel budgets | same prompts across datasets by construction |

### D.3 Dataset table

| Dataset | $n$ | Mean targets/image | OPM median | Instance state | Role |
|---|---|---|---|---|---|
| SFCHD | 12,066 | 1.45 | 1.11 | Large, clear | Sparse primary benchmark |
| ShanghaiTech-B test | 316 | 123.8 | 118.3 | Medium, partly occluded | Medium density |
| UCF-QNRF test | 334 | 718.9 | 96.3 | Small, densely overlapping | High density, large images |
| ShanghaiTech-A test | 182 | 433.3 | 784.7 | Very small, severe overlap | Very high density |
| CountBench | 491 | 6.04 | 31.1 | Large, clear | VLM-native benchmark |
| TallyQA | 498 | 8.2 | 48.0 | Large, clear | External validity |
| FSC-147 | 600 | 80.8 | ~180 | Medium, class-agnostic | External validity |
| VisDrone (person) | 400 | 22.4 | — | Very small, low contrast | Aerial extreme |
| AI-TOD (person) | 226 | 17.0 | — | Very small, near-indistinguishable | Aerial extreme |

---

## Appendix E. Detection ladders in full

### E.1 The fine $\tau$ ladder in full

| Input regime | Domain (mean GT) | min $\lvert$ME$\rvert$ | $\tau^\*$ | 95% CI | Reachable |
|---|---|---|---|---|---|
| Whole image | SFCHD test (1.4) | 0.0 | **0.259** | [0.236, 0.277] | yes |
| Whole image | ShanghaiTech-B (123.8) | 0.2 | **0.130** | [0.118, 0.144] | yes |
| Whole image | **ShanghaiTech-A (433.3)** | **140.9** | — | — | **no** (100% bootstrap-unreachable) |
| Whole image | **UCF-QNRF (718.9)** | **543.1** | — | — | **no** (100%) |
| Tiled 1024 | UCF-QNRF (718.9) | 1.9 | **0.131** | [0.105, 0.162] | yes |
| Tiled 1024 | **ShanghaiTech-A (433.3)** | **141.1** | — | — | **no** (100%) |


### E.2 NMS IoU and input scale

| NMS IoU | $\tau^\*$ | 95% CI |
|---|---|---|
| 0.5 | **0.038** | [0.027, 0.054] |
| 0.6 | **0.073** | [0.055, 0.097] |
| 0.7 | **0.121** | [0.099, 0.148] |


### E.3 The two-family tiling ladder

| Family | Dataset | Whole | tile-1024 | tile-512 | tile-256 |
|---|---|---|---|---|---|
| YOLO | UCF-QNRF | — | **0.121** | **0.176** | **0.173** |
| YOLO | **ShanghaiTech-A** | — | **no** (min $\lvert$ME$\rvert$ **141.1**) | **0.260** | **0.183** |
| YOLO | ShanghaiTech-B | — | 0.128 | 0.420 | 0.240 |
| RetinaNet | **UCF-QNRF** | **no** (**531.2**) | **0.124** | 0.225 | 0.306 |
| RetinaNet | **ShanghaiTech-A** | **no** (**244.3**) | **no** (**244.3**) | **0.124** | 0.237 |
| RetinaNet | ShanghaiTech-B | 0.060 | 0.060 | 0.278 | 0.376 |


### E.4 Monotonicity of $\tau^\*$ under finer tiling

| Dataset | Family | tile-1024 | tile-512 | tile-256 | Trend |
|---|---|---|---|---|---|
| UCF-QNRF | YOLO | 0.121 | 0.176 | 0.173 | **non-monotone** |
| UCF-QNRF | RetinaNet | 0.124 | 0.225 | 0.306 | monotone increasing |
| ShanghaiTech-A | YOLO | unreachable | 0.260 | 0.183 | **non-monotone** |
| ShanghaiTech-A | RetinaNet | unreachable | 0.124 | 0.237 | monotone increasing |


### E.5 The two zeros, by source-domain weights

| Source-domain weights | $\tau^\*(\delta_U = 0)$ (95% CI) | $\tau^\*(\delta_T = 0)$ (95% CI) |
|---|---|---|
| Fusion (in-domain) | **0.1106** [0.1004, 0.1205] | **0.2347** [0.2258, 0.2440] |
| COCO-pretrained | **0.0980** [0.0872, 0.1122] | **0.2236** [0.2159, 0.2317] |
| SHWD-pretrained | **0.1048** [0.0921, 0.1186] | **0.2142** [0.2059, 0.2226] |


---

## Appendix F. Span spectrum in full

### F.1 Same-scale accuracy across the three families

| Dataset | Detection (native 1024 tiling at $\tau^\*$) | VLM-32B (best tiling level) | Density regression (best weight) | Density regression (weight range) |
|---|---|---|---|---|
| ShanghaiTech-A | 220.5 | 201.7 (5×5) | **71.3** | 71.3–383.4 (**5.4×**) |
| UCF-QNRF | 287.3 | 284.3 (6×6) | **221.3** | 221.3–1240.1 (**5.6×**) |
| ShanghaiTech-B | 31.2 | 33.2 (3×3) | **9.8** | 9.8–133.4 (**13.6×**) |


### F.2 The six knobs, their sides, and their spans

| Family | Knob | Side | Pooled span | Zero-crossing units | Primary target |
|---|---|---|---|---|---|
| Detection / enumeration | threshold $\tau$ × input size | parameter side | **30.0–90.0 pp** | 3/4 | direction |
| Density regression | input scale (multiplier / fixed short side) | input-scale side | **20.1–34.3 pp** (official DM-Count) | 3/4 | direction |
| VLM | output contract (`forbid0`/`choice`/`range`) | language side | **26.8–53.7 pp** | 6/6 | direction |
| VLM | prompt family (V1…V5) | language side | pooled **25–2008 pp** / per-item median **19–70 pp** | 12/15 pooled / 3–6/15 median | direction |
| VLM | tiling level | vision side | **1.9–28.6 pp** | 7/13 | abstention, secondarily direction |
| VLM | pixel budget | vision side | **4.0–14.6 pp** | 0/6 | abstention only |


### F.3 The split-point enumeration

| Split | Max upper bound, low group | Min lower bound, high group | Gap | Verdict |
|---|---|---|---|---|
| $k = 1$ (pixel budget / ShanghaiTech-A alone) | 4.2 | 4.5 | **+0.2 pp** | separated, but a single unit |
| **$k = 3$ (three pixel-budget units)** | **22.4** | **24.0** | **+1.6 pp** | **the only meaningful separation** |
| $k = 2, 4, 5, 6, 7, 8, 9$ | — | — | −5.4 to −81.0 pp | intervals overlap |

The ten units over which these splits are enumerated are listed with their spans and
bootstrap intervals in **F.9**; the three that form the low group at $k = 3$ are the pixel-budget
units, and the remaining seven are the high group.

---

## Appendix G. The three excluded mechanism hypotheses: pre-registered criteria and per-cell data

§7.7 states that all three candidate explanations for the directional effect of `forbid0` are excluded.
This appendix carries the pre-registered criteria and the per-cell data behind that statement.

### G.1 Mediation by abstention rate: pre-registered, and negative

**Background.** On BBBC005 (abstention ≈ 1%) the effect of `forbid0` is near zero, which suggests a
mechanistic reading: *the effect of `forbid0` is proportional to the amount of abstention it can convert*.
That inference confounds domain with abstention rate, because the two happen to move in the same direction
between BBBC005 and the dense domains. The correct test **manipulates abstention rate** and asks whether
the effect follows.

**Design — criteria fixed before the numbers were seen.** The tiling level is a ready-made abstention
manipulator (32B on ST-A: whole image **56.6%** → 2×2 **6.0%** → 3×3 **1.1%**). A contract-arm ×
tiling-level factorial was run over 8B and 32B × {`base`, `forbid0`, `choice`, `range`} ×
{whole, 2×2, 3×3} × {ST-A, UCF}, reusing the tiling and aggregation logic byte-identically.

- **H**: if the effect of `forbid0` is proportional to convertible abstention, then |Δ| must tend to zero
  as abstention falls.
- **C**: if the `choice` channel is independent of abstention, then |Δ| must **not** vanish as abstention falls.

| Configuration / domain | Abstention (whole → 2×2 → 3×3) | `forbid0` Δ | `choice` Δ |
|---|---|---|---|
| 32B / ST-A | **56.6% → 6.0% → 1.1%** | +185.2 → +194.7 → +166.5 pp (flat) | +153.9 → +351.6 → **+412.3** pp |
| 32B / UCF | **53.6% → 9.9% → 1.2%** | +166.1 → +200.2 → +161.9 pp (flat) | +99.3 → +258.9 → **+319.6** pp |
| 8B / ST-A | 0.0% → 0.0% → 0.0% | +27.6 → +34.1 → +24.2 pp | +136.7 → +434.4 → **+689.9** pp |
| 8B / UCF | 0.6% → 0.0% → 0.0% | +27.1 → +39.5 → +36.7 pp | +78.6 → +282.5 → **+433.6** pp |

Δ is the item-intersection paired difference against `base` at the same model, domain and level, with
20,000 permutation draws. The `range` arm is likewise a strong directional knob, **+72 to +370 pp**.

**Result: H is rejected; C is confirmed and strengthened.**

1. **H fails.** With 32B abstention compressed to **1.1%**, Δ for `forbid0` is nearly unchanged
   (+185 → +195 → +167 pp). More decisively, 8B has **0.0% abstention at every level** and still shows a
   non-zero Δ of **+24 to +40 pp**. `forbid0` therefore does not act by converting answers of zero; it
   moves the **location** of the answered distribution.
2. **C holds, and is strengthened.** Δ for `choice` **increases monotonically with tiling depth in all four
   cells**, while abstention falls to zero. The channel is entirely independent of abstention, and its
   authority **grows as input legibility improves** — a stronger and more useful statement than the one it
   replaces: high legibility does not merely remove abstention, it enlarges the authority of the
   language-side knobs.
3. **There is no two-branch split.** `forbid0` is a strong directional knob at every abstention level in the
   dense domains (+160 to +200 pp for 32B), yet near zero on BBBC005 (+0.6 to +5.8 pp); its magnitude is
   set by the **domain**, not by the abstention rate.

### G.2 The decisive controlled test: a synthetic grid with n and σ varying independently

To turn "ground-truth magnitude sets the scale" from an observed association into a controlled conclusion,
the three contract arms were added to a **synthetic disc grid on which ground-truth count n and blur σ vary
independently** (n ∈ {100, 400, 800} × r ∈ {2, 4, 8} × σ ∈ {0, 1, 2, 4, 8} × 15 = **675 items**), run on
three configurations: Qwen3-VL-8B, Qwen3-VL-32B and InternVL2.5-8B.

**Pre-registered criterion.** If Δ grows strongly with n and only weakly with the answered-zero flux, the
scale factor is the ground-truth magnitude. If the reverse holds, the observational conclusion is a domain
artefact. If Δ ≈ 0 and uncorrelated with both, the magnitude-factor account holds.

| Configuration | Abstention channel | max abs Δ(`forbid0`) | r(~n) | r(~answered-zero flux) | Δ stratified by n (100/400/800) |
|---|---|---|---|---|---|
| Qwen3-VL-8B | answered zero | 40.0 pp | −0.005 | −0.053 | 23.2 / 3.4 / 21.2 pp |
| Qwen3-VL-32B | answered zero | 31.3 pp | +0.645 | +0.487 | −2.6 / −4.0 / +17.3 pp |
| **InternVL2.5-8B** | refusal / non-numeric | **42.2 pp** | +0.527 | +0.130 | **−24.3 / −9.3 / −4.0 pp** |

**Three negations.**

1. **Magnitude mismatch.** On ST-A, Δ for 32B in the observational data is of order **+184 to +185 pp**,
   whereas on the controlled grid the largest value in any configuration is **31–42 pp**.
2. **The predicted null fails.** InternVL2.5-8B was expected to show Δ ≈ 0, on the reasoning that its
   abstention travels through a refusal / non-numeric channel with no answered zeros to rewrite; on the
   grid its Δ spans **−24.3 to +18.9 pp** across strata, reaching a maximum absolute value of **42.2 pp**,
   i.e. the same order as Qwen.
3. **The most direct refutation.** At σ = 8, n = 800 the 32B base abstention rate is **100%** — every item
   answered zero. If `forbid0` acted by converting answered zeros, this cell should show a very large Δ.
   The measured value is **+14.2 pp**. This removes both the answered-zero-flux mechanism and a strong
   ground-truth effect; the n-stratified means show no monotone trend either.

The mechanism claim is therefore **downgraded**: `forbid0` is strongly associated with ground-truth
magnitude on real crowd and aerial images (r = +0.91 **within the Qwen family**, see G.3), but the
association **does not reproduce** on the controlled grid, and its cause remains open. This points to an
unexamined domain dependence — the strong effect may require some property of real images (crowding,
semantic ambiguity) rather than the numerical magnitude of the ground truth. **This is the most important
unresolved mechanism question in the paper.**

### G.3 Mediator correlation analysis, and the downgraded statement

Across the 13 (model, domain) units:

| Candidate mediator | correlation with Δ(`forbid0`) | reading |
|---|---|---|
| **median ground truth** | **r = +0.779** (within the Qwen family **+0.914**) | strong |
| base abstention rate | r = +0.078 | unrelated |
| P(pred = 0) over all items | r = +0.078 | unrelated (identical to abstention rate for Qwen) |
| P(pred = 0) over abstaining items | r = +0.270 | weak |
| Δ(`choice`) against all four of the above | abs r ≤ 0.26 | no single predictor |

Grouped by the abstention-channel structure of the lineage (§3.6, Appendix B.3):

| Family | Abstention channel | median GT range | Δ(`forbid0`) | within-family r(Δ~GT) |
|---|---|---|---|---|
| **Qwen** (32B / 8B / 2.5-7B) | **answered zero** | 18 – 388 | **+0.5 to +248.3 pp** | **+0.914** |
| **InternVL2.5-8B** | **refusal / non-numeric** | 18 – 273 | **−2.0 to +4.3 pp** | +0.995 (magnitude negligible) |

The earlier mechanism statement is hereby **downgraded to unconfirmed**. It read that the effect of
`forbid0` is the product of a *magnitude factor* — whether the model expresses uncertainty as an answered
zero, giving up to +250 pp for Qwen and no object to rewrite for InternVL — and a *scale factor*, the
ground-truth magnitude. The controlled grid of G.2 does not support it. What survives is narrower and is
what the main text claims: **abstention rate itself is not a mediator** (r = +0.08). Compressing 32B
abstention on ST-A to 1.1% leaves Δ unchanged, and Qwen2.5-7B abstains only 1.6% on ST-A yet still shows
**+136.7 pp**.

Two things remain unseparated: (i) "answered-zero flux × ground truth" and "the whole distribution shifts,
by an amount that grows with ground truth" cannot be distinguished with the present data; (ii) the
interaction is observed on **two lineages only** and is not extrapolated to a general law.

### G.4 The methodological criterion this case yields

The difficulty here was **treating "domain" as a mechanistic variable**: BBBC005 and the dense domains
differ in domain *and* in abstention rate simultaneously, so without manipulation the two cannot be told
apart. The generalisable criterion is therefore: **to claim that A acts on C through B, B must be actively
manipulated**; otherwise the effects of A and of B are not identifiable.

## Appendix H. Density-regression protocols and measurements

### H.1 A log-ratio counting consistency loss

Adding a counting-consistency term on the log ratio between the predicted integral and the ground-truth
count reduces the seed-to-seed spread by roughly an order of magnitude and removes most of the systematic
positive offset that the uncorrected training objective leaves behind. We report this as a remedy for a
training artefact rather than a new architecture: part of what is usually attributed to the family is
attributable to the objective.

### H.2 Abstention is stably measurable only under greedy decoding

Under sampling-based decoding the abstention rate is not a stable property of the model, since it
co-varies with the sampling temperature and the number of samples. Under greedy decoding the answer is
deterministic and the rate reproducible. This is why the VLM protocol fixes temperature at 0 and why
the non-determinism that remains is attributed to the serving stack rather than to the model
(Appendix A.3).

### H.3 Collapse under overlap is independent of model scale

A 2×2 factorial contrast (8B versus 32B) shows that the collapse of density-regression output under
overlap — where the predicted density ceases to respond to further increases in the true count — occurs
for both models at comparable overlap levels. The collapse is therefore a property of the task structure
rather than of model capacity, and is a further instance of the capacity floor of §5.7.

---

## Appendix I. Data-hygiene ledger

**Quarantine tiers.** Records whose key fields could not be read are isolated in graded tiers rather
than dropped silently. Tier 1 contains runs whose result files were unavailable because of server-side
errors during collection; tier 2 contains runs superseded by a corrected re-execution; tier 3 contains
files whose declared configuration columns disagree with the values re-derived from the outcome columns.
Every analysis reported in the main text was recomputed without tier 1 and tier 2, and the affected
figures are reported on the cleaned set; the corresponding per-tier item counts are recorded in the
project's data-freeze manifest, which accompanies this submission as a separate file.

**Sentinel and range rules.** A predicted value at or above `1e5`, or equal to the exact sentinel
value 1234567890, is treated as an unparsed response rather than as a count, and is excluded before any
rate is computed. Records with a non-positive ground truth are excluded from ratio computations, since
the per-image ratio is undefined for them; this affects the sparse sets only, and the affected rows are
counted rather than dropped implicitly.

**Declared-versus-derived disagreements.** In 238 records the pipeline's declared abstention flags
disagree with the values re-derived from `pred`, `parse_ok` and `raw`. These are enumerated individually
and resolved by hand; they are never resolved by a precedence rule, so that the resolution cannot
silently propagate an assumption.

**Reversal.** Because the tiers and the sentinel rule are recorded rather than applied in place, a reader
who prefers the uncleaned view can reconstruct it: the freeze manifest names the files in each tier, and
no row was deleted from the underlying result tables.

## Appendix J. Proofs and verification evidence for Propositions 4–6

Every number in this appendix is **computed from the corpus** by `p4_decomp_verify.py`, not transcribed;
re-running that script reproduces the tables below. The corpus conventions are those of Appendix I
(de-duplicate by `item`, drop `pred ≥ 1e5`, drop unparseable `pred`, drop `gt ≤ 0` from ratio
computations).

### J.1 Proposition 4: the identity and its closed form

With $G$, $G_N$, $P$ and $w=G_N/G$ as defined in §3.8, and abstained items contributing $pred=0$:

$$\rho_{\text{total}}=\frac{P-G}{G},\quad \rho_{\text{answered}}=\frac{P-G_N}{G_N},\quad P=G_N(1+\rho_{\text{answered}})
\ \Longrightarrow\ \rho_{\text{total}}=w(1+\rho_{\text{answered}})-1 .$$

| Quantity | Result |
|---|---|
| Result files scanned / logical units | **136 / 131** |
| Files where the identity applies | **95** |
| Maximum residual $\lvert\rho_{\text{total}}-w(1+\rho_{\text{answered}})+1\rvert$ | **$1.9\times10^{-16}$** |
| Structurally inapplicable | **41** (no abstention: every item answered) |
| Closed form $S$: files checked, max $\lvert S_{\text{measured}}-S_{\text{closed}}\rvert$ | **88**, **$7.5\times10^{-14}$** |
| Scope boundary: residual under the per-image-median convention | **0.01–47.38 pp** |

**Additive decomposition, by dataset** (Qwen3-VL-32B, `base` contract arm, whole-image;
**canonical primary runs only**, i.e.07% | -76.41% | -4.67% | -81.07% | 0.2359 | -19.79% |
| UCF-QNRF | -86.75% | -81.27% | -5.48% | -86.75% | 0.1873 | -29.25% |
| VisDrone | -71.10% | -58.39% | -12.71% | -71.10% | 0.4161 | -30.54% |
| AI-TOD | -80.16% | -67.17% | -12.99% | -80.16% | 0.3283 | -39.57% |
| FSC-147 | -68.55% | -24.89% | -43.66% | -68.55% | 0.7511 | -58.13% |
| TallyQA | -21.78% | -2.75% | -19.03% | -21.78% | 0.9725 | -19.57% |
| CountBench | 2.09% | -0.81% | 2.90% | 2.09% | 0.9919 | 2.92% |

Every row satisfies $\rho_{\text{total}}=-\!(1-w)+w\,\rho_{\text{answered}}$ to rounding, and $w$ and
$\rho_{\text{answered}}$ here reproduce both the closed-form $S$ of the table above and the dual-convention
gaps quoted in §5.11(a) (61.3 / 57.5 / 40.6 / 40.6 pp) — the reconciliation is asserted by the build's
arithmetic check rather than left to the reader.

The two extremes are instructive: on the dense crowd domain almost the whole under-count is abstention
(−76.83 of −80.29 pp), whereas on FSC-147 the answering term dominates (−43.66 of −68.55 pp), and on
CountBench the two terms have opposite signs.

**Independent confirmation.** §5.11(a) reports a dual-convention gap of **61.3 / 57.5 / 40.6 / 40.6 pp**.
Proposition 4 predicts that gap as $\rho_{\text{total}}-\rho_{\text{answered}}=-(1-w)(1+\rho_{\text{answered}})$;
the four reported values are reproduced to within **0.04 pp**. The proposition therefore derives a number
the paper had obtained by a separate route, rather than restating it.

**Abstention share $S$, canonical primary runs only** (the corpus also holds derived re-runs of some cells;
those are excluded here — the largest divergence between a primary run and its re-run is **0.809 pp** on
$\rho$, Appendix J.4):

| Unit (base contract arm) | $S$ measured | $S$ closed form | abstention rate (unweighted) |
|---|---|---|---|
| Qwen3-VL-32B / ShanghaiTech-A | 94.2% | 94.2% | 56.6% |
| Qwen3-VL-32B / UCF-QNRF | 93.7% | 93.7% | 53.9% |
| Qwen3-VL-32B / AI-TOD | 83.8% | 83.8% | 68.1% |
| Qwen3-VL-32B / VisDrone | 82.1% | 82.1% | 68.2% |

**Scope of the 82–94% headline.** Those four cells are the **base contract arm**, and they are what the main
text's 82–94% refers to. Across the other contract arms and domains the same quantity ranges from **42.5%**
(ShanghaiTech-B, `under` arm — a cell whose abstention rate is itself only 13.6%) to **99.4%**
(ShanghaiTech-A, `under` arm). The `over` arm has **no abstentions at all** — its prompt requires every
possible target to be counted — so its abstention share is **0%** in every domain, and the dense
`base` cells sit at **93.7–94.2%** with their `under` counterparts at **98.4–99.4%**. The claim the paper makes — that the dominant component of the aggregate under-count is
abstention rather than estimation error — holds across that whole range; the narrower 82–94% is the base-arm
range and is not presented as a universal bound.

### J.2 Proposition 5

The proof is the two-line computation given in §3.8. Its purpose is to make the calibration objection
**falsifiable**: an affine recalibration of a unit's admitted levels multiplies every span by one number,
the fitted slope $s$, so a claim that spans are calibration artefacts must report $s$. Non-affine
recalibration is outside the proposition's scope and is why the quantile map is treated separately.

### J.3 Proposition 6

The witness is the pair (VisDrone or AI-TOD) versus ShanghaiTech-A: the lowest targets-per-image
(17–22) alongside ShanghaiTech-A's 433, with comparable abstention (68% vs. 57%). The
operational criterion that follows — *a candidate stratifier must show monotone abstention in it* — is
what the paper applies when it stratifies by legibility rather than by OPM.

### J.4 An observed bound on run-to-run non-determinism

The corpus holds, for six configurations, an independent re-run of the same (model, dataset, contract
arm, tiling level). Their aggregate $\rho$ differs by at most **0.81 pp**:

| Configuration | copies' $\rho_{\text{total}}$ | spread |
|---|---|---|
| 32B / st_a / base / whole | −80.286% / −81.075% | 0.789 pp |
| 32B / st_a / base / tile2 | −50.799% / −51.608% | 0.809 pp |
| 32B / st_a / base / tile3 | −36.370% / −36.801% | 0.431 pp |
| 32B / ucf / base / whole | −86.245% / −86.750% | 0.505 pp |
| 32B / ucf / base / tile2 | −58.727% / −59.104% | 0.377 pp |
| 32B / ucf / base / tile3 | −46.236% / −45.697% | 0.539 pp |

This bounds the fragility disclosed in §8.1 with a measured value, and it sits far inside the paper's own
indistinguishability threshold of 7 pp. Numbers reported in the main text are taken from the **primary
run directories** (`dense_results`, `aerial_results`, `ext_results`, `e8b_*`, `q25_*`, `ivl_*`), never
from the derived re-run directory `b2__out_*`.

## Appendix K. Implementation-span readings behind the §1 evidence

The three implementation-level readings quoted in §1 and §7.5 are listed here with their protocol so that
they can be checked against the same rules as every other span in the paper. All three are pooled relative
deviations over the **density-regression input-scale knob**, evaluated on the **common item intersection**
of the compared runs, at the same task, domain and protocol.

| Implementation | Pooled span | Zero-crossing cells | Note |
|---|---|---|---|
| Official **DM-Count** weights | **20.1–34.3 pp** | 3/4 | common item intersection; the implementation of record |
| Official **P2PNet** weights | **10.1 pp** | — | official weights, same protocol |
| A superseded reproduction of the same CSRNet architecture | **107.0–1432.9 pp** | 3/4 | **implementation defect**, not a paradigm difference; retained only as the reason §7.5 reports implementation effect as 2–3.4× across official implementations |

The ratio quoted in the main text (5–42×) is the ratio between the last row and the official rows; it is a
statement about **implementation quality within one architecture family**, and the paper does not use it to
argue that density regression is intrinsically less directionally controllable. The same distinction is
applied in §7.5, where the official-implementation effect is reported as **2–3.4×** and the defective
reproduction is labelled as the cost of an implementation defect.

### A.4 Detail moved from §2.8 (evaluation validity)

We therefore treat model-to-model
differences below **7 pp** as indistinguishable and decline to report one difference that flips under
repetition (Appendix A.3).

### D.4 Figure and table plan moved from §3.9

The remaining figures — per-cell
detection ladders, per-level saturation curves, the contract prediction distribution, the cross-implementation
knob curves and the scale-invariance panels — are provided in the supplementary file, as are the per-cell
tables referenced from Appendices E–G. Table 1 is the lineage-stratified abstention table of §3.6; the
numerosity-stimulus comparison of §2.5 is Table 2. All tables are supplied as editable text with no
vertical rules and no shading.

### F.4 Saturation-slope detail moved from §7.5

For the clean 4× parameter pair the difference is
$\Delta b = +0.00124$, paired bootstrap 95% CI $[+0.00079, +0.00165]$, $p < 0.0001$, against a replication
baseline of $0.00012$ and $0.00001$ — a scale effect **10–124×** the baseline. Both split-half checks
reproduce the same sign and magnitude.

### G.5 Per-cell numbers moved from §7.7

**Conclusion:** `forbid0`'s effect is **stably observable** but its mechanism is **undetermined**;
it is reported as a **usable directional knob** (§5.8), not as a mechanistically explained finding
(pre-registered criteria and per-cell data in Appendix G).

### A.5 Per-level mean/median note moved from §7.8

A curve drawn through per-level medians can
therefore differ from the scatter of per-image values by more than the effects being discussed, so
per-level medians are always shown with their interquartile spreads.

### F.5 Enumeration-versus-regression support moved from §7.10

The dense-end results here quantify why —
the density-regression family's scale freedom parameter and its weight-set spread (5.4–13.6×) together
dominate any directional difference between families, so a regression-style model must be calibrated per
domain before its direction can be compared at all.

### F.6 Reporting-norm recommendation detail moved from §7.11

**Match the effective target scale** — comparisons at unmatched scale are not
comparisons. **Report the weight-set distribution** rather than a single number, since the same
architecture spans 5.4–13.6× across usable weights. **Report the abstention rate separately**, with its
own convention label, since without it a refusal is recorded as a small estimate. Where these are not
observed, the scale and weight nuisance parameters can each produce differences of **90–275 pp**, enough
to invert the ranking of the paradigms being compared.

### J.5 Proofs and verification for Propositions 7–8

**Proposition 7.** With two exhaustive abstention channels and refusal fraction $f$
($0 < f < 1$), the number of items a report records as abstaining is $(1-f)A$ where $A$ is the true
abstention count, so the relative error is $f$. Writing $\kappa$ for answered zeros divided by refusals,
$\kappa = (1-f)A / (fA) = (1-f)/f$, hence $f = 1/(\kappa+1)$ — the identity is independent of $A$ and
therefore of the corpus size. Substituting the measured $\kappa$ values of §3.6 Table 1 gives
$1/551.6 = 0.18\%$ and $6{,}096/20{,}111 = 30.31\%$ (equivalently $1/(\kappa+1)$ with
$\kappa = 14{,}015/6{,}096 = 2.2990$, which rounds to the 2.3 : 1 printed in Table 1; the rounded
$\kappa = 2.3$ gives 30.30%, so the exact ratio is used here).

**Proposition 8.** The bound follows from the identity of Proposition 4 by taking absolute values, and
attainment for $\rho_{\text{answered}}<0$ is immediate because both factors are then positive. Numerically,
using the canonical primary runs of Appendix J.1 ($w$ and $\rho_{\text{answered}}$ printed in that table):

| Domain | $w$ | $\rho_{\text{answered}}$ | identity $(1-w)(1+\rho_{\text{ans}})$ | observed gap |
|---|---|---|---|---|
| ShanghaiTech-A | 0.2359 | −19.79% | **61.33 pp** | 61.3 pp |
| UCF-QNRF | 0.1873 | −29.25% | **57.50 pp** | 57.5 pp |
| VisDrone | 0.4161 | −30.54% | **40.56 pp** | 40.6 pp |
| AI-TOD | 0.3283 | −39.57% | **40.59 pp** | 40.6 pp |

All four cells reproduce the reported gap to within **0.04 pp**, so the identity above is what generates the
dual-convention gap in every domain measured; the earlier reading of two cells as "below the bound" came
from a mis-computed column and is withdrawn. The distinction that matters for §5.7 is unaffected: the gap
is a function of the abstention mass $1-w$ and of $\rho_{\text{answered}}$, and both are reported.

### A.6 Note moved from §2.4 (cascade errors)

We use
such a decomposition explicitly as a **definitional identity** ($\delta_U = \delta_T - \delta_H$,
verified exactly per image, §4.7), and warn against treating it as an empirical finding: any two of the
three quantities determine the third.

### E.7 Non-monotonicity detail moved from §4.6

This is
one more instance of the paper's rule: **every entry in the response spectrum must be labelled with
{implementation × training domain × data domain × protocol}**, since generalising either family's trend
would be wrong.

### J.6 Numeric examples moved from §5.11(b)–(c) (ground-truth trend and scale effect)

Proposition 4 expresses this gap as $-(1-w)(1+\rho_{\text{answered}})$, so the four reported values are a **consistency check on the numbers printed in this paper** rather than an independent empirical prediction: all four values are
reproduced to within **0.04 pp**, so the convention gap is a **derived** quantity rather than a
bookkeeping artefact. **(b) The abstention rate rises steeply with ground truth, flipping the sign of the slope between
conventions.** In the dense synthetic domains the rate climbs with GT (32B: ShanghaiTech-A **27.5% →
85.7%**, $r = +0.490$; UCF **22.0% → 86.1%**, $r = +0.529$), so the slope of $\rho = a + b\,\text{GT}$
**reverses sign** (**−0.00051 → +0.00037**): much of the reported "negative saturation slope" is
manufactured by abstention rather than being a scale response. ShanghaiTech-B is the only domain whose
abstention rate is identically zero, and its two-convention slopes agree exactly (**−0.00168 to
−0.00230**) — the only uncontaminated testbed. **Every directional conclusion here is reported under both
conventions.**

**(c) The scale effect is domain-dependent.** A 4× parameter increase (8B → 32B) enlarges the directional
span by **2.5–3.1×** and the abstention amplitude by **7.4–7.5×** in the dense synthetic domains, but
neither in the aerial domain (**0.66–1.18×** and **0.8–1.3×**). We do **not** claim larger models are
always more directionally controllable.

## Appendix L. Per-property numbers moved from §1

The four statements in §1 are summarised without their numbers; the numbers themselves are given below verbatim, and each also appears where it is first used in §5.

Measured, that ratio is **550.6 : 1** for
Qwen3-VL-32B, unbounded for Qwen3-VL-8B and Qwen2.5-VL-7B (no refusals at all), and only **2.3 : 1** for
InternVL2.5-8B. The indicator is complete for the Qwen family — the source of all our abstention
headlines — and covers only about **70%** for InternVL, so **cross-lineage comparison requires
lineage-specific channel definitions** (§3.6).

A further consequence is that the
abstention rate rises steeply with ground truth (27.5% → 85.7%, $r = +0.490$), flipping the slope of the
"relative deviation vs. GT" relation between conventions (**−0.00051 → +0.00037**) — so much of the
reported "negative saturation slope" on dense domains is manufactured by abstention (§5.11).

### I.2 Runner-defect detail moved from §8.1

**Two runner defects, located, with stated workarounds.** The first could write results into a directory
already populated by a different model, producing **duplicate rows for the same item** or, more
insidiously, silently writing nothing while reporting success — leaving "new" results that were the
previous model's. The second concerned a missing field in one output format. Both are mitigated by
model-specific output directories and by de-duplicating on `item` while counting duplicates; we report
them because the affected numbers would otherwise be silently contaminated rather than visibly wrong.

### J.7 Per-cell values behind the capacity floor, moved from §5.7

Real images restricted to the answered subset give $\rho = -19.8\%$ (ShanghaiTech-A) and $-29.2\%$
(UCF-QNRF). Its order of magnitude is lower than previously thought: on microscopy it appears from about
**ten targets onwards** ($[1,10)$ is exactly **+0.0%**, $[60,101)$ reaches **−53.8%**; pooled convention,
confined to these models and domains).

### C.4 Aerial contract-effect detail moved from §5.10

Lowering the pixel budget raises abstention monotonically in both lineages: InternVL **41.5% → 54.5%**,
Qwen **59.5% → 72.5%**. The "forbid 0" instruction works only partly for Qwen (**59.5% → 45.5%**) and
hardly at all for InternVL (**41.5% → 40.0%**).

### L.1 Scale contrast details moved from §5.9

The 32B abstention amplitude is **7.4–7.5×** larger than the 8B's and its directional span 2.5–3.1×
larger. Comparing 8B and 32B alone suggests that scale enables zero crossing, but the smallest
configuration (Qwen2.5-VL-7B) crosses in **2/5** units exactly as the 32B does, while both 8B
configurations cross in **0/5**.

## Appendix M. The channel is set by the output contract: the discriminating experiment (E1)

### M.1 Design and comparability

The corpus leaves one question open: an answered zero may be an abstention, or a genuine estimate of
zero. E1 makes the channel an experimental variable. The sample is the items on which the corpus
configuration answered exactly 0 — **103** on ShanghaiTech-A (ground truth 138–797) and **180** on
UCF-QNRF (137–2075) — from which **40 per domain** are drawn at equal spacing after sorting by ground
truth. Sampling is deterministic, so all configurations and all arms share the same 40 items per
domain; frame membership, duplicate keys and out-of-frame rows were checked file by file (40/40, no
duplicates). Arms: `base` (the corpus prompt, unchanged), `permit` (explicitly allowed to answer
`abstain`), `bestA`/`bestB`/`bestC` (abstention forbidden and a best estimate demanded, three
phrasings), and `channel` (an explicit three-way option: a number, `cannot_judge`, or `no_people`).
The `base` and `permit` arms carry five repeats per item.

Comparability was verified rather than assumed: the `base` prompt, the image encoding (JPEG q92), the
parsing and the output columns are reused verbatim from the corpus runner, and the `base` prompt was
compared **codepoint by codepoint** against it (identical). Hosted calls use temperature 0,
`max_tokens` 128, with exponential backoff on 429/5xx. **The comparison is at the level of
configurations, not of precision**: the corpus ran a 4-bit `compressed-tensors` AWQ checkpoint on
vLLM 0.29.0, while the hosted endpoints differ in **both** weight precision and serving engine, so E1
establishes configuration dependence without attributing it to either cause.

### M.2 All 48 cells

Counts are over successful calls; `ERR` counts the 429-driven failures, which are excluded from every
rate below rather than counted as abstentions.

| model | ds | arm | rows | valid | ERR | answered 0 | median pred/gt | pooled dev |
|---|---|---|---|---|---|---|---|---|
| `qwen3-vl-235b-a22b-instruct` | st_a | base | 240 | 237 | 3 | 0 | 0.670 | -13.9% |
| `qwen3-vl-235b-a22b-instruct` | st_a | bestA | 40 | 39 | 1 | 0 | 7.519 | 719.8% |
| `qwen3-vl-235b-a22b-instruct` | st_a | bestB | 40 | 40 | 0 | 0 | 8.040 | 732.6% |
| `qwen3-vl-235b-a22b-instruct` | st_a | bestC | 40 | 39 | 1 | 0 | 9.452 | 1471.7% |
| `qwen3-vl-235b-a22b-instruct` | st_a | channel | 40 | 39 | 1 | 0 | — | — |
| `qwen3-vl-235b-a22b-instruct` | st_a | permit | 240 | 236 | 4 | 0 | — | — |
| `qwen3-vl-32b-instruct` | st_a | base | 240 | 240 | 0 | 76 | 0.635 | -34.3% |
| `qwen3-vl-32b-instruct` | st_a | bestA | 40 | 40 | 0 | 0 | 6.354 | 676.9% |
| `qwen3-vl-32b-instruct` | st_a | bestB | 40 | 40 | 0 | 0 | 6.017 | 521.8% |
| `qwen3-vl-32b-instruct` | st_a | bestC | 40 | 40 | 0 | 0 | 4.263 | 400.8% |
| `qwen3-vl-32b-instruct` | st_a | channel | 40 | 40 | 0 | 0 | — | — |
| `qwen3-vl-32b-instruct` | st_a | permit | 240 | 240 | 0 | 0 | — | — |
| `qwen3-vl-8b-instruct` | st_a | base | 40 | 40 | 0 | 0 | 0.276 | -75.7% |
| `qwen3-vl-8b-instruct` | st_a | bestA | 40 | 40 | 0 | 0 | 2.463 | 307.2% |
| `qwen3-vl-8b-instruct` | st_a | channel | 40 | 40 | 0 | 0 | — | — |
| `qwen3-vl-8b-instruct` | st_a | permit | 40 | 40 | 0 | 0 | — | — |
| `qwen3-vl-flash` | st_a | base | 40 | 40 | 0 | 0 | 0.990 | 37.6% |
| `qwen3-vl-flash` | st_a | bestA | 40 | 40 | 0 | 0 | 6.868 | 875.5% |
| `qwen3-vl-flash` | st_a | channel | 40 | 40 | 0 | 0 | — | — |
| `qwen3-vl-flash` | st_a | permit | 40 | 40 | 0 | 0 | — | — |
| `qwen3-vl-plus` | st_a | base | 40 | 40 | 0 | 0 | 0.627 | -36.8% |
| `qwen3-vl-plus` | st_a | bestA | 40 | 40 | 0 | 0 | 7.689 | 1123.6% |
| `qwen3-vl-plus` | st_a | channel | 40 | 40 | 0 | 0 | — | — |
| `qwen3-vl-plus` | st_a | permit | 40 | 40 | 0 | 0 | — | — |
| `qwen3-vl-235b-a22b-instruct` | ucf | base | 240 | 238 | 2 | 1 | 0.573 | -18.1% |
| `qwen3-vl-235b-a22b-instruct` | ucf | bestA | 40 | 39 | 1 | 0 | 4.315 | 906.9% |
| `qwen3-vl-235b-a22b-instruct` | ucf | bestB | 40 | 39 | 1 | 0 | 4.704 | 778.3% |
| `qwen3-vl-235b-a22b-instruct` | ucf | bestC | 40 | 39 | 1 | 0 | 6.903 | 1340.0% |
| `qwen3-vl-235b-a22b-instruct` | ucf | channel | 40 | 39 | 1 | 0 | — | — |
| `qwen3-vl-235b-a22b-instruct` | ucf | permit | 240 | 237 | 3 | 0 | — | — |
| `qwen3-vl-32b-instruct` | ucf | base | 240 | 240 | 0 | 62 | 0.691 | -38.0% |
| `qwen3-vl-32b-instruct` | ucf | bestA | 40 | 40 | 0 | 0 | 4.480 | 622.2% |
| `qwen3-vl-32b-instruct` | ucf | bestB | 40 | 40 | 0 | 0 | 4.002 | 438.9% |
| `qwen3-vl-32b-instruct` | ucf | bestC | 40 | 40 | 0 | 0 | 3.787 | 415.7% |
| `qwen3-vl-32b-instruct` | ucf | channel | 40 | 40 | 0 | 0 | — | — |
| `qwen3-vl-32b-instruct` | ucf | permit | 240 | 240 | 0 | 0 | — | — |
| `qwen3-vl-8b-instruct` | ucf | base | 40 | 40 | 0 | 2 | 0.002 | -94.5% |
| `qwen3-vl-8b-instruct` | ucf | bestA | 40 | 40 | 0 | 0 | 2.565 | 269.8% |
| `qwen3-vl-8b-instruct` | ucf | channel | 40 | 40 | 0 | 0 | — | — |
| `qwen3-vl-8b-instruct` | ucf | permit | 40 | 40 | 0 | 0 | — | — |
| `qwen3-vl-flash` | ucf | base | 40 | 40 | 0 | 0 | 0.654 | -1.3% |
| `qwen3-vl-flash` | ucf | bestA | 40 | 40 | 0 | 0 | 6.135 | 873.0% |
| `qwen3-vl-flash` | ucf | channel | 40 | 40 | 0 | 0 | — | — |
| `qwen3-vl-flash` | ucf | permit | 40 | 40 | 0 | 0 | — | — |
| `qwen3-vl-plus` | ucf | base | 40 | 40 | 0 | 0 | 0.501 | -41.2% |
| `qwen3-vl-plus` | ucf | bestA | 40 | 40 | 0 | 0 | 7.255 | 1145.6% |
| `qwen3-vl-plus` | ucf | channel | 40 | 40 | 0 | 0 | — | — |
| `qwen3-vl-plus` | ucf | permit | 40 | 40 | 0 | 0 | — | — |

### M.3 Answered zeros by configuration (`base` arm)

| configuration | st_a: answered 0 | ucf: answered 0 |
|---|---|---|
| `qwen3-vl-235b-a22b-instruct` | 0/237 = 0.0% | 1/238 = 0.4% |
| `qwen3-vl-32b-instruct` | 76/240 = 31.7% | 62/240 = 25.8% |
| `qwen3-vl-8b-instruct` | 0/40 = 0.0% | 2/40 = 5.0% |
| `qwen3-vl-flash` | 0/40 = 0.0% | 0/40 = 0.0% |
| `qwen3-vl-plus` | 0/40 = 0.0% | 0/40 = 0.0% |

### M.4 The abstention arms and the forbidden-abstention arms

| arm | valid calls | explicit abstentions | answered 0 |
|---|---|---|---|
| `permit` | 1193 | 1193 (100.0%) | 0 |
| `channel` | 398 | 398 (100.0%) | 0 |
| **total** | **1591** | **1591 (100.0%)** | **0** |

In the **18** forbidden-abstention cells there are **no** answered zeros and **no** refusals, and the
median predicted/true ratio runs **2.463–9.452** — i.e. forbidding abstention does not produce small
numbers, it produces systematic **over**-estimation.

### M.5 The corpus already contains the same structure

The corpus varies the prompt's permission to be conservative, and the answered-zero rate follows it
monotonically (**832** items per arm):

| prompt arm | instruction | answered 0 | st_a | st_b | ucf |
|---|---|---|---|---|---|
| `over` | count every possible target | **0/832 = 0.0%** | 0/182 | 0/316 | 0/334 |
| `base` | neutral | **283/832 = 34.0%** | 103/182 | 0/316 | 180/334 |
| `under` | count only what you can fully confirm | **519/832 = 62.4%** | 171/182 | 43/316 | 305/334 |

The arm instructed to include every possible target produced **no** answered zeros at all, over 832
items — the same mechanism, visible inside the original corpus and independent of E1.

### M.6 The runner's parse branch is dead, with zero measured impact

The corpus runner's pattern expects the object key **unquoted** — an opening brace, optional
whitespace, the key `count` (or one of the runner's non-English synonyms for that key), a colon and a
digit run — whereas the prompt asks for `{"count": N}`; the structured branch therefore never matches
and
every stored value comes from the fallback "first integer anywhere in the response". A row-by-row audit
of all **2496** rows of the three-arm prompt experiment (832 items x 3 arms) shows the two readings agree in **2496** rows, with **0**
rows containing no digit at all and **0** rows where the JSON value could not be recovered;
all **802** answered zeros are literally `{"count": 0}`. The defect is therefore real but has
**no** effect on the released values, and it independently rules out a parsing artefact as the origin
of the zeros.

### M.7 What E1 establishes, and what it does not

**Established.** (i) On the items the corpus answered 0, an answered zero is not what these
configurations do when an alternative is available: **1591/1591** successful calls abstained
explicitly and none answered 0. (ii) The zero does not require the quantised local deployment — the
hosted checkpoint of the corpus configuration reproduces it on **25.8–31.7%** of the same items — and
is not a universal family behaviour, since `plus`, `flash` and `235b` answer 0 on **0–0.4%**. (iii) A
zero is not a failed estimate: with abstention forbidden the model over-estimates by a median of
**2.463–9.452×** rather than approaching zero. (iv) The corpus's own `over` arm, instructed to
include everything, produced no answered zeros in **832** items.

**Not established.** The re-query confounds weight precision with serving engine; the item set is
selected for having been answered 0, so a genuine estimate of zero outside it is not excluded; and the
experiment covers the dense crowd domains only, not the aerial ones.

### F.7 Statistical-structure arithmetic moved from §7.3

Only one split separates: three pixel-budget units with a maximum upper bound of **22.4 pp** against the
remaining seven with a minimum lower bound of **24.0 pp** — a gap of **1.6 pp**, permutation
$p \approx 0.008$ **before** any correction for the nine enumerated split points. The smallest attainable
corrected value is therefore of order $0.07$, which is not significant at this sample size, and the
1.6 pp gap is itself **below the paper's own noise floor of 2.15–6.46 pp**. Within the high-response
group **6 of 6 adjacent pairs overlap**.

### F.8 Span is not a single construct: per-unit values moved from §7.2

Endpoint spans derive **54–80%** of their magnitude from the single most extreme level, and the mean
absolute deviation is a different quantity: the VisDrone pixel-budget unit has the **highest** mean
$\lvert\rho\rvert$ at 32.7 with one of the smallest spans.

### F.9 The ten (knob × domain) units, isotonic-calibrated

The span spectrum of F.2 pools each knob over its domains; the split-point enumeration of F.3 instead runs
over **ten (knob × domain) units**, listed here in full so that the enumeration is reproducible. Spans are
in percentage points of the pooled relative deviation; the interval is a 300× bootstrap 95% CI under the
isotonic-calibrated (monotone, shape-free) reading, which is the reading §7.3 quotes. The **group** column
gives the $k = 3$ split of F.3: the three pixel-budget units form the low group, the other seven the high
group.

| Unit (knob / domain) | Shared affine | **Isotonic** | Quantile map | Isotonic 95% CI | Group at $k=3$ |
|---|---|---|---|---|---|
| Detection, in-domain / VisDrone | 103.9 | **150.7** | 254.8 | [98.3, 172.2] | high |
| VLM, output contract / InternVL | 23.0 | **97.7** | 87.9 | [74.0, 179.2] | high |
| VLM, output contract / Qwen3-VL-32B | 58.5 | **85.9** | 90.0 | [71.1, 109.0] | high |
| Detection, zero-shot COCO | 56.0 | 54.2 | 283.1 | [43.3, 93.0] | high |
| Detection, in-domain / BBBC005 | 79.4 | **49.0** | 61.2 | [45.0, 57.7] | high |
| Density regression, official DM-Count / UCF-QNRF | 31.9 | 36.6 | 37.5 | [24.0, 48.7] | high |
| Density regression, official DM-Count / ShanghaiTech-A | 32.5 | 33.5 | 34.3 | [29.5, 42.3] | high |
| VLM, pixel budget / UCF-QNRF | 8.6 | 17.2 | 4.7 | [4.5, 19.6] | **low** |
| VLM, pixel budget / VisDrone | 14.2 | 16.8 | 32.9 | [11.4, 22.4] | **low** |
| VLM, pixel budget / ShanghaiTech-A | 1.5 | **1.1** | 1.4 | [0.4, 4.2] | **low** |

The two numbers that appear in §7.3 are visible here: the high-response group spans **33.5–150.7 pp**
(its minimum and maximum isotonic values) and the low group is bounded above by **22.4 pp** (the upper end
of the VisDrone pixel-budget interval), against a high-group minimum lower bound of **24.0 pp** (the
DM-Count/UCF interval) — the 1.6 pp gap of F.3.

Two readings of this table matter for the paper's claims. First, the **noise floor** is 2.15–6.46 pp, so
the pixel-budget unit on ShanghaiTech-A (**1.1**, CI [0.4, 4.2]) lies inside it and is not used for any
claim; the other two pixel-budget units (16.8 and 17.2) do exceed it. Second, calibration family changes
individual units substantially — BBBC005 falls from 79.4 to **49.0** and the pixel-budget/VisDrone unit
*rises* from 14.2 to 16.8 — which is why the table reports all three families rather than one.

### M.8 Numeric detail moved from §§5.8, 5.9, 5.10, 7.4, 7.6 and 5.11

These are the per-cell numbers behind the corresponding claims in the main text; the
claims themselves remain in the main text with a pointer to this subsection.

**§5.8.** Across seven prompt-strength levels the accepted integer set contracts and its mean is pushed
toward zero, the extreme level driving abstention to **94.0% / 91.3%** on two configurations — the knob
acts on the distribution of the emitted value rather than on a perception threshold.

**§5.9.** Answered-only relative deviation: ShanghaiTech-A **−67.5%** (8B) vs. **−19.8%** (32B);
UCF-QNRF **−69.7%** vs. **−29.2%**.

**§5.10.** 2×2 tiling lowers VisDrone abstention from **68.2%** to about **47%**, against the crowd
domain's **56.6% → 6.0%**.

**§5.10 (arms).** The *over* arm reaches only **−56.3% / −66.3%** on the two aerial domains.

**§7.4.** Aerial: the in-domain ladder moves $\rho$ from **+507.4%** to **−0.9%**. Dense crowds: no
lineage reaches `pred/gt ≥ 1` at any threshold and the span collapses to **6–19 pp**. Training-domain
swap alone: **55.5 → 195.7 pp** (3.5×). Zero-shot COCO detectors move from 2/3 to 0/3 zero-crossing
units once model-appropriate matching is applied.

**§7.6.** `choice` moves the relative deviation across zero by **+238.4 pp** while the abstention rate
moves by **0.08 pp**. `forbid0`: ShanghaiTech-A **+115.6 pp**, UCF **+76.0 pp**, BBBC005 **+0.6 to +5.8 pp**.

**§5.11(a).** The dual-convention gap is **61.3 pp** (ShanghaiTech-A), **57.5 pp** (UCF) and **40.6 pp**
(AI-TOD and VisDrone).

### M.9 Numeric detail moved from §§4.1, 4.3, 4.7, 5.5, 7.3 and 7.9

Per-cell numbers behind the corresponding main-text claims, moved verbatim; each
claim remains in the main text with a pointer here.

**§4.3.** Across the ladder **21
configurations are reachable and 5 are not**, with reachable $\tau^\*$ values in **0.021–0.259**; the full
table is in Appendix E.1. The essential qualification is that **the unreachable configurations are not
marginally out of reach** — the minimum $\lvert$ME$\rvert$ is **140.9–141.1** for ShanghaiTech-A and
**543.1** for whole-image UCF. This converts "unreachable" from "a little more tuning would do" into **the
absence of directional controllability under $\tau$ for that configuration**.

**§4.1.** The reason is measurable: the **highest** `pred/gt` reached
anywhere on the $\tau$ ladder is **1.004 / 1.688 / 2.094** for the in-domain YOLO weights but only
**0.179 / 0.339 / 0.631** for the same architecture with COCO-pretrained weights, and on the dense domains
COCO detectors reach only **≈ 0.10–0.21** at any threshold. Reachability therefore has a checkable criterion (**Fig. 4**) — is `pred/gt ≥ 1` attained at the lowest threshold? —
which gives **zero exceptions** across three lineages and nine cells.

**§4.7.** Decomposing the cascade error on a safety-helmet task
into a user-side error $\delta_U$ and a head-level error $\delta_H$ with total $\delta_T$, and locating
both zeros on **the same 12,066 images**, gives $\tau^\*(\delta_U = 0)$ in **0.0980–0.1106** and
$\tau^\*(\delta_T = 0)$ in **0.2142–0.2347** across three source-domain weight sets (Appendix E.5). **The two differ by a factor of about 2.1–2.3 and their intervals do not overlap**, so quoting one number
is not reproducible. **Each zero is individually stable** (ranges only **0.0126** and **0.0205** across
three weight sets), so §4.1's domain conditionality is consistent with a stable zero *within* a domain.

**§7.3.** Only one split
separates, by **1.6 pp**, at $p \approx 0.008$ before correction — which neither the paper's own noise
floor (**2.15–6.46 pp**) nor the nine enumerated split points allows us to treat as established (the
arithmetic, including the order-$0.07$ corrected value, is in Appendix F.7). We therefore report the
separable low-response cluster as a **candidate structure** rather than an established partition, and we
claim **one separable low-response cluster** (VLM pixel budget, ≤ 22.4 pp) alongside an **internally
continuous high-response spectrum** (33.5–150.7 pp) — and explicitly **not** two anchor zones or
bimodality, since with four knob **sides** collapsed into ten units a bimodality test has very low power.

**§5.5.** Across the other arms the same quantity runs from **42.5%** — ShanghaiTech-B under the `under` arm, a cell
whose abstention rate is itself only 13.6% — to **99.4%** (ShanghaiTech-A, `under` arm); the `over` arm has **0%** — its prompt requires every
possible target to be counted, so it never abstains — and the dense `base` cells sit at
**93.7–94.2%**. The **unweighted** counterpart is 53.9–68.2%. The
two differ by **38–40 pp** on ShanghaiTech-A and UCF, which is why both must be reported. Setting refusals
aside entirely, the answered-only relative deviation is only **−19.8%** and **−29.2%** — these models are
much closer to unbiased than the aggregate suggests.

### M.11 Numeric detail moved from §4, §5 and §6

Per-cell numbers behind the corresponding main-text claims, moved verbatim; every
claim sentence remains in the main text with a pointer here.

**5.7 Abstention and under-counting are two separable failure modes.** Its signature is severe output degeneracy:
the number of unique predicted values per configuration has a median of only **17–23** (range 9–29)
against hundreds of distinct ground-truth values — abstention is the extreme point of this collapse. **The channel is set by the output contract, not by the lineage (E1).** On the 40 items per dense
domain that the corpus configuration answered exactly 0, four further configurations were queried
under identical prompts. Given an explicit abstention option, **1591 of 1591** successful calls
(**100%**; five configurations, two domains, two phrasings) abstained explicitly and **none**
answered 0. Forbidding abstention and demanding a best estimate produced **no** zeros and **no**
refusals but a median of **2.463–9.452×** the true count, so a zero is neither a failed estimate nor
a small one. The zero reappears only under the numeric-only contract, and then only for part of the
family: the hosted checkpoint matching the corpus configuration answers 0 on **25.8–31.7%** of these
items, whereas `plus`, `flash` and `235b` answer 0 on **0–0.4%**.

**3.5 Implementations.** **VLMs:** Qwen3-VL-32B-


*Causal attribution of abstention: not count, but legibilitygibil.** On
**count-controlled synthetic grids**, changing only arrangement and blur drives abstention from 0% to
90%. **Across domains**, abstention relates weakly to target count ($r = +0.33$; ShanghaiTech-B with 124
targets abstains at 0% while VisDrone with 22 abstains at 68%). And **within a grid**, holding count,
size and blur fixed and varying only arrangement: dispersed gives 0% abstention and $\rho = -58\%$,
clustered gives 90% and $\rho = -100\%$ — a 90 pp jump in abstention and 42 pp in bias from arrangement
alone.

**7.2 Same-scale accuracy comparison across the three families.** **Density regression attains the highest accuracy** on all three datasets once the scale
protocol is matched — 71.3 / 221.3 / 9.8 against 220.5 / 287.3 / 31.2 for detection and 201.7 / 284.3 /
33.2 for the 32B VLM. **Its reliability is the lowest**: across eleven usable weight sets for the same
architecture and data, MAE differs by **5.4–13.6×**. **Detection is the best value**, within roughly
1.6–3× of the best density regression while offering a directional knob.Language-side contracts: channel independence, and one excluded branchnd one e.** And **`forbid0` is the strongest directional contract in dense domains** yet nearly inert on BBBC005 [40] (*per-arm values in Appendix M.8*). **The cause of that boundary is not "no answered zero left to rewrite"** (see §7.7: after tiling drives
the 32B abstention rate from **56.6%** to **1.1%**, the effect is essentially unchanged,
**+185 → +195 → +167 pp**).

**5.9 Model scale: what is bought is knowing whether to answer.** What scale changes is **abstention** — the 32B model abstains where
the 8B answers confidently and wrongly. **The ability to cross zero does not emerge with scale**: a
Qwen2.5-VL-7B configuration — the smallest — crosses in **2/5** units exactly as the 32B does, while both
8B configurations cross in **0/5**.

**1. Introduction.** Counting
evaluation, however, reports **symmetric magnitude** metrics — MAE, RMSE and their normalised forms —
for which counting 100 objects as 50 and as 150 are indistinguishable, although the two are not
interchangeable in any deployment decision.

**2.9 Crowded-scene occlusion counting.** The separation is
measured here: when the occluded position **can** be inferred the abstention rate equals the unoccluded
control exactly (both 0%), and when it cannot the rate rises to **60–90%**.

**5.8 The two routes to removing abstention, and their price.** **Route B — relaxing the prompt (bypass
legibility; destroys accuracy)** also drives abstention from **53–57%** to zero, but flips $\rho$ from
**−82%** to **+234%…+345%** (canonical convention, anomalies removed).

**5.10 Aerial domain: the legibility extreme.** Whole-image abstention rates are **68.2%** and **68.1%**,
and **none** of the three arms moves the direction positive — the opposite of the crowd domain.

### M.14 Numeric detail moved from §§6.2, 7.9, 7.10 and 7.11

Per-cell numbers behind the corresponding main-text claims, moved verbatim.

**§7.9.** Its boundary must be stated at the same time: across ten independent family × dataset
combinations, restricting to the most legible 20% leaves $\lvert\rho\rvert$ reduced to a median retention
ratio of **0.69** (range **0.61–0.83**), never to zero.

### M.16 Detail moved from §§4–7

Moved verbatim; the topic sentence and every claim sentence remain in Tile granularity: a third knob, which can turn unreachable into reachablewhich can turn unreach.** First, **tile granularity can rescue an
unreachable configuration**: ShanghaiTech-A is unreachable for YOLO at tile-1024 (min
$\lvert$ME$\rvert$ = **141.1**) but reachable from **tile-512** ($\tau^\*$ = 0.260), and for RetinaNet it
is unreachable even at tile-1024 (**244.3**) and becomes reachable only at **tile-512** (0.124). "This
domain is unreachable" is therefore not an absolute property of the domain but a **joint property of
{domain × input protocol}**. Second, **the two families unseal at different granularities**: RetinaNet, a
pre-FPN architecture, needs finer tiling than YOLO to unseal the same domain.

**7.7 Three mechanism hypotheses, tested and excluded.** **Synthetic reproduction — fails**: the effect is **+124 to +248 pp** on crowd images against only
**+20 pp** on synthetic discs even at $\sigma = 0$, a tenfold difference. **Overlap/occlusion — not
supported**: a 2×2×4×10 factorial decoupling crowding from size gives $\Delta = +0.3$ pp in the critical
cell. 

### M.17 Detail moved from §1, §6.2 and §7.3

Moved verbatim; every claim sentence remains in the main text.

**§1 supporting result.** Three independent pieces of evidence: official DM-Count
weights give **20.1–34.3 pp** and official P2PNet **10.1 pp** within one task, domain, protocol and item
intersection, whereas a retired reproduction of the same CSRNet [4] architecture gives **107–1433 pp** on the
same ladder — a **5–42× implementation difference within one architecture family** (per-implementation readings and protocol in Appendix K; this is the cost of an implementation defect, not a paradigm difference); the same detection architecture under a
training-domain swap changes span from **55.5 pp** to **195.7 pp** (**3.5×**); and "side of action" does
not predict span.
