# -*- coding: utf-8 -*-
"""对 PR 官方条款逐项体检本稿（只读）。
条款出处：E:\\workplace\\PR网页.txt（作者复制，875 行；含期刊专属 Writing and formatting 节）。
"""
import io
import os
import re
import sys

sys.stdout.reconfigure(encoding='utf-8')
MS = r'D:\deepseek\PaperB\PaperB_英文稿_PR_20260919.md'
SUP = r'D:\deepseek\PaperB\PaperB_英文补充材料_PR_20260919.md'
HL = r'D:\deepseek\PaperB\review_pkg_20260919\07_Highlights.md'
t = io.open(MS, encoding='utf-8').read()
sup = io.open(SUP, encoding='utf-8').read()
W = lambda s: len(re.findall(r"[A-Za-z][A-Za-z'\-]*", s))

print('=' * 92)
print('① 摘要 ≤250 词（条款 L310/L583）')
ab = t.split('## Abstract')[1].split('## 1. Introduction')[0]
ab = ab.split('**Keywords:**')[0]   # Keywords 不属摘要
print('   实测 %d 词  -> %s' % (W(ab), 'OK' if W(ab) <= 250 else '**超 %d 词**' % (W(ab) - 250)))

print('② 关键词 1–7 个（条款 L329/L583）')
kw = re.search(r'(?im)^(?:##\s*)?(?:\*\*)?keywords?(?:\*\*)?\s*[::]', t)
print('   %s' % ('找到: ' + t[kw.start():kw.start() + 90].replace('\n', ' ') if kw else '**未找到关键词段**'))

print('③ Highlights：必交、3–5 条、每条 ≤85 字符、文件名含 Highlights（条款 L334–L340/L597–L600）')
if os.path.exists(HL):
    h = io.open(HL, encoding='utf-8').read()
    bullets = [l.strip() for l in h.split('\n') if re.match(r'^\s*[-*•]|^\s*\d+[.)]', l)]
    over = [b for b in bullets if len(re.sub(r'^\s*[-*•\d.)]+\s*', '', b)) > 85]
    print('   文件存在；%d 条；超 85 字符的 %d 条' % (len(bullets), len(over)))
    for b in bullets[:6]:
        s = re.sub(r'^\s*[-*•\d.)]+\s*', '', b)
        print('      (%3d 字符) %s' % (len(s), s[:80]))
    if over:
        for b in over:
            print('      **超限**: %s' % b[:100])
else:
    print('   **缺文件** %s' % HL)

print('④ 标题建议 ≤10–15 词（条款 L581）')
title = t.split('\n')[0].lstrip('# ').strip()
print('   %d 词: %s' % (W(title), title[:110]))

print('⑤ 是否有 Conclusions 节（条款 L585–L586）')
heads = [l.strip() for l in t.split('\n') if l.strip().startswith('## ') or l.strip().startswith('### ')]
print('   顶层节: %s' % [h.lstrip('# ')[:28] for h in heads if h.startswith('## ')])
has_concl = any('conclusion' in h.lower() for h in heads)
print('   含 Conclusions 节: %s' % ('是' if has_concl else '**否**'))

print('⑥ 参考文献条数应在 35–55（条款 L721）')
nref = len(re.findall(r'(?m)^\d+\. ', t.split('## References')[1]))
print('   实测 %d 条 -> %s' % (nref, 'OK' if 35 <= nref <= 55 else '**越界**'))

print('⑦ 参考文献必须**按正文首次出现顺序**编号（条款 L693）')
body, refs = t.split('## References')[0], t.split('## References')[1]
first = {}
for m in re.finditer(r'\[(\d+(?:\s*,\s*\d+)*)\]', body):
    for n in re.findall(r'\d+', m.group(1)):
        first.setdefault(int(n), m.start())
order = [n for n, _ in sorted(first.items(), key=lambda kv: kv[1])]
print('   正文出现的编号顺序（前 20）: %s' % order[:20])
print('   编号总数 %d；顺序是否单调递增: %s' % (len(order), '是' if order == sorted(order) else '**否（列表需重排）**'))
missing = sorted(set(range(1, nref + 1)) - set(order))
print('   列表里有、正文未引: %s' % (missing or '无'))

print('⑧ 英文一致（条款 L863：美式或英式，不可混用）')
us = len(re.findall(r'\b\w+(?:ize|ization|yze|analyze|behavior|color|modeling|labeled|center)\w*\b', body))
uk = len(re.findall(r'\b\w+(?:ise|isation|yse|behaviour|colour|modelling|labelled|centre)\w*\b', body))
print('   美式形 %d 处 / 英式形 %d 处 -> %s' % (us, uk, '**混用**' if us and uk else 'ok'))
for pat in ('behaviour', 'behavioural', 'analyze', 'analyse', 'modeling', 'modelling', 'labeled', 'labelled'):
    c = len(re.findall(pat, body, re.I))
    if c:
        print('      %-12s %d' % (pat, c))

print('⑨ 是否有 Data availability / 数据声明（条款 L524–L527 Option C 必交）')
d = [h for h in heads if re.search(r'data (availability|statement)|availability of data', h, re.I)]
print('   %s' % (d or '**未找到数据可用性段**'))

print('⑩ 是否已有 CRediT / 生成式 AI 声明 / 致谢（条款 L632/L140–L166）')
for key, pat in (('CRediT', r'CRediT'), ('生成式 AI 声明', r'generative AI|AI-assisted technologies'),
                 ('Acknowledg', r'^#+ *Acknowledg')):
    print('   %-14s %s' % (key, '有' if re.search(pat, t, re.I | re.M) else '**无**'))
